import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  const [ text, setText ] = React.useState("Good Morning");

  const handleSubmit = () => {
    let t = text;
    if (text === "Good Morning") {
      t = "Good Afternoon"
    } else {
      t = "Good Morning"
    }
    setText(t)
  }
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <p>
          {text}
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <button onClick={handleSubmit}>Submit</button>
      </header>
      { ChangeInput() }
      { FocusInput() }
    </div>
  );
}

function ChangeInput() {
  const [name, setName] = React.useState("");
  return (
    <div>
      <span data-testid="change-input-greeting">
        Welcome, {name === "" ? "Anonymous User" : name}!
      </span>
      <br />
      <input 
        type="text" 
        aria-label="user-name" 
        placeholder="Your name"
        value={name}
        onChange={e => setName(e.target.value)}
      />
    </div>
  );
}


const FocusInput = () => {
  const inputRef = React.useRef(null);
  return (
    <div>
      <input 
        type="text" 
        aria-label="focus-input" 
        ref={inputRef}
        placeholder="Focus me!"
      />
      <button onClick={() => inputRef.current.focus()}>Click to Focus</button>
    </div>
  )
}

const HOC = (WrappedComponent) => {
  return class extends React.Component {
      constructor() {
        super();
        this.state = {
          name: "Naveen"
        }
      }
      render() {
        return (
          <div>
            <WrappedComponent />
          </div>
        )
      }
  } 
}

const newCom = HOC(<App />)

const useFetch = (url) => {
  const [ data, setData ] = useState(null);

  useEffect((url)=> {
    fetch(url).then((res)=> res.json()).then(
      (v)=> setData(v)
    ).catch(()=>{})
  }, [])

  return [data];
}

export default App;
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import App from './App';

test("Testing the rendering of text", () => {
  render(<App />);
  let link = screen.getByText(/Learn React/i);
  expect(link).toBeInTheDocument();
})

test("Testing the rendering of text2", ()=> {
  render(<App />);
  let text = screen.getByText(/Edit/i);
  expect(text).toBeInTheDocument();
})

test("Testing the rendering of button with action", ()=> {
  render(<App />);
  let button = screen.getByRole("button", { name: /submit/i});
  fireEvent.click(button);
  expect(screen.getByText(/afternoon/i)).toBeInTheDocument();
  fireEvent.click(button);
  expect(screen.getByText(/morning/i)).toBeInTheDocument();
})

test("Testing the on change event", ()=> {
  render(<App />);
  let input = screen.getByLabelText("user-name");
  let greeting = screen.getByTestId("change-input-greeting");
  expect(input.value).toBe("");
  expect(greeting.textContent).toBe("Welcome, Anonymous User!");
  fireEvent.change(input, { target: { value: "Naveen"}});
  expect(input.value).toBe("Naveen");
  expect(greeting.textContent).toBe("Welcome, Naveen!");
})

test("checking focus functionality", ()=> {
  render(<App />);
  let button = screen.getByText("Click to Focus");
  fireEvent.click(button);
  expect(document.activeElement).toBe(screen.getByPlaceholderText("Focus me!"));
})

test("async func", async () => {
  render(<App />);
  const handleFilter = jest.fn();
  fireEvent.click(screen.getByRole("button"));
  expect(handleFilter).toBeCalled();
  expect(handleFilter).toHaveBeenCalledWith([{name: "ii"}]);

  jest.mock("axios");

  axios.get.mockResolvedValues({ data: []})

  const data = waitFor(()=> screen.findByTestId("td"))
})
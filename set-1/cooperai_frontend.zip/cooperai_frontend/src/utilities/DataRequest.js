import axios from './../axios.js';
import { REACT_API_URL } from './../constants';

export const xhrClient = {
    async requestBase(route, requestMethod, customRequestHeaders, data, responseType = "json", params, requestConfig = null) {
        const request = {
            method: requestMethod,
            url: `${REACT_API_URL}${route}`,
            responseType,
            headers: {
                'accept': 'application/json',
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            params: params
        }

        if (requestMethod !== 'get') {
            request.data = data;
        }
        if (requestConfig) {
            request.config = requestConfig;
        }
        return await axios(request)
            .then((response) => {
                const responseData = response.data? response.data : response;
                return responseData;
            })
            .catch((error) => {
                throw error.data;
            })
    },

    //...GET
    async get(route, customRequestHeaders = null, data = null, responseType = "json", params = {}) {
        const requestMethod = 'get';
        return this.requestBase(route, requestMethod, customRequestHeaders, data, responseType, params);
    },
    //...POST
    async post(route, customRequestHeaders = null, data = null, responseType = "json", params = {}, requestConfig = null) {
        const requestMethod = 'post';
        return this.requestBase(route, requestMethod, customRequestHeaders, data, responseType, params, requestConfig);
    },
    //...PUT
    async put(route, customRequestHeaders = null, data = null, responseType = "json", params = {}) {
        const requestMethod = 'put';
        return this.requestBase(route, requestMethod, customRequestHeaders, data, responseType, params);
    },
    //...DELETE
    async delete(route, customRequestHeaders = null, data = null, params = {}) {
        const requestMethod = 'delete';
        return this.requestBase(route, requestMethod, customRequestHeaders, data, params);
    }
}
import { createSlice } from '@reduxjs/toolkit';

var varianceData = [ 
    { "id": 1, "category": "Net Revenue", "plValue": null, "masterDataValue": null, "client": "Client2" }, 
    { "id": 2, "category": "Cost Bucket 1", "plValue": null, "masterDataValue": null, "client": "Client2" }, 
    { "id": 3, "category": "Cost Bucket 2", "plValue": null, "masterDataValue": null, "client": "Client2" }, 
    { "id": 4, "category": "Cost Bucket 3", "plValue": null, "masterDataValue": null, "client": "Client2" } 
]

const statusMappping1 = {
  "Initial": "Field Mapping",
  "Field Mapping": "Initial",
}

const statusMappping2 = {
  "Initial": "Field Mapping",
  "Field Mapping": "Analytics",
  "Analytics": "Initial"
}

const statusMappping3 = {
  "Initial": "Calculations",
  "Calculations": "Sanity",
  "Sanity": "Analytics",
  "Analytics": "Initial",
}

export const statusStagesMappingForVariance = {
  'p&l module': statusMappping1, 
  'Org_module': statusMappping1,
  'Margin_module': statusMappping3,
  'Vendor_module': statusMappping2,
}

var initialState = {
  varianceIdentificationData: varianceData,
  masterData: [],
  plValues: [],
  initialData: true,
  varianceAllocationData: [],
  dataAllocationStatus: "",
  analyticsGeneratingStatus: ""
}

const getFormattedDropdownData = (v)=> ({ value: v, name: v });

const varianceDataSlice = createSlice({
  name: 'varianceData',
  initialState,
  reducers: {
    setVarianceIdentificationData(state, action) {
        if (action.payload.varianceData && action.payload.varianceData.length) {
          state.varianceIdentificationData = action.payload.varianceData;
        } else {
          state.varianceIdentificationData = varianceData.map((v)=> ({...v, client: action.payload.clientName}))
        }
        state.masterData = action.payload.marginValues? action.payload.marginValues.map(getFormattedDropdownData): [];
        state.plValues = action.payload.plValues ? action.payload.plValues.map(getFormattedDropdownData): [];
        state.initialData = action.payload.initialData;
    },
    setVarianceData(state, action) {
        state.varianceIdentificationData = action.payload;
    },
    setVarianceAllocationData(state, action) {
      state.varianceAllocationData = action.payload;
    },
    setAllocationStatus(state, action) {
      state.dataAllocationStatus = action.payload;
    }
  },
})

export default varianceDataSlice.reducer;

//Actions
export const {
    setVarianceIdentificationData,
    setVarianceData,
    setVarianceAllocationData,
    setAllocationStatus
} = varianceDataSlice.actions;

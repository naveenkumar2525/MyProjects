import { xhrClient } from './../../utilities/DataRequest';

const getVarianceIdenDataService = (clientName) => {
    return xhrClient.get(`/api/v1/variance/identification/${clientName}`);
}

const saveVarianceIdenDataService = (data) => {
    return xhrClient.post('/api/v1/variance/identification', null, data);
}

const updateVarianceIdenDataService = (data) => {
    return xhrClient.put('/api/v1/variance/identification', null, data);
}

const getVarianceAllocationService = (clientName) => {
    return xhrClient.get(`/api/v1/variance/data/${clientName}`);
}

const saveAllocationDetailsService = (clientName, requestBody) => {
    return xhrClient.post(`/api/v1/variance/data/${clientName}`, null, requestBody);
}

const proceedForAllocationService = (clientName, module, status) => {
    return xhrClient.get(`/api/v1/variance/data/trigger/${clientName}/${module}/${status}`);
}

const proceedForAnalyticsService = (clientName, module) => {
    return xhrClient.get(`/api/v1/variance/data/analytics/${clientName}/${module}`);
}

export {
    getVarianceIdenDataService,
    saveVarianceIdenDataService,
    updateVarianceIdenDataService,
    getVarianceAllocationService,
    saveAllocationDetailsService,
    proceedForAllocationService,
    proceedForAnalyticsService
};

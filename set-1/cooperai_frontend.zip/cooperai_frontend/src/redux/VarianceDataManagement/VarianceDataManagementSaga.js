import { call, put, takeEvery, all } from 'redux-saga/effects';
import { getFieldMappingStatusService } from '../DataMappingView/DataMappingViewService';
import { setCurrentStatusStage, setErrorFileDetails } from '../DataMappingView/DataMappingViewSlice';
import { SNACKBAR_ERROR, SNACKBAR_SUCCESS } from '../GlobalSlices/snackbar';
import { 
    getVarianceAllocationService,
    getVarianceIdenDataService,
    proceedForAllocationService,
    proceedForAnalyticsService,
    saveAllocationDetailsService,
    saveVarianceIdenDataService,
    updateVarianceIdenDataService } from './VarianceDataManagementService';
import { 
    setAllocationStatus,
    setVarianceAllocationData,
    setVarianceIdentificationData,
    statusStagesMappingForVariance
} from './VarianceDataManagementSlice';

function* getVarianceIdentificationData(data) {
    try {
        const response = yield call(getVarianceIdenDataService, data.payload);
        let formattedResponse = { ...response};
        if (response.initialData === true) {
            formattedResponse.clientName = data.payload;
        }
        yield put(setVarianceIdentificationData(formattedResponse));
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error?.message}));
    }
}

function* saveVarianceIdentificationData(data) {
    const requestObject = {
        variance: data.payload.varianceIdentificationData
    }
    try {
        const response = yield call(saveVarianceIdenDataService, requestObject);
        yield call(getVarianceIdentificationData, { payload: data.payload.clientName})
        yield put(SNACKBAR_SUCCESS(response.status));
        const { navigate } = data.payload;
        navigate(`/client/${data.payload.clientName}/variance_data`);
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error?.message}));
    }
}

function* updateVarianceIdentificationData(data) {
    const requestObject = {
        variance: data.payload.varianceIdentificationData
    }
    try {
        const response = yield call(updateVarianceIdenDataService, requestObject);
        yield call(getVarianceIdentificationData, { payload: data.payload.clientName})
        yield put(SNACKBAR_SUCCESS(response.status));
        const { navigate } = data.payload;
        navigate(`/client/${data.payload.clientName}/variance_data`);
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error?.message}));
    }
}

function* getVarianceAllocationData(data) {
    try {
        const response = yield call(getVarianceAllocationService, data.payload);
        yield put(setVarianceAllocationData(response.variance));
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error?.message}));
    }
}

function* saveVarianceAllocationData(data) {
    try {
        const requestObject = { variance: data.payload.body }
        const response = yield call(saveAllocationDetailsService, data.payload.clientName, requestObject);
        //yield put(SNACKBAR_SUCCESS(response.status));
        yield put(setAllocationStatus("INPROGRESS"));
        yield call(delay, 15000);
        yield call(getPerformanceAllocationStatus, data);
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error?.message}));
    }
}

function* getPerformanceAllocationStatus(data) {
    try {
        const { module, clientName, currentStatusStage } = data.payload;
        const response = yield call(getFieldMappingStatusService, module, clientName, currentStatusStage);
        yield put(setAllocationStatus(response.status));
        if (response.status === "ERROR" || response.status === "HOLD") {
            yield put(setErrorFileDetails(response));
            yield put(SNACKBAR_ERROR({message: "Error Found", action: true, stopAutoHide: true}));
        } else if (response.status === "SUCCESS") {
            if (statusStagesMappingForVariance[module][currentStatusStage] === "Initial") {
                yield put(SNACKBAR_SUCCESS("Data Saved Successfully"));
            }
            yield put(setCurrentStatusStage(statusStagesMappingForVariance[module][currentStatusStage]));
        } else if (response.status === "EXCEPTION" || response.status === "error") {
            yield put(SNACKBAR_ERROR({message: "Internal Exception Occured"}));
            yield put(setCurrentStatusStage("Initial"));
        }
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error?.message}));
    }
}

const delay = time => new Promise(resolve => setTimeout(resolve, time));

function* proceedForAllocation(data) {
    yield put(setAllocationStatus(""));
    try {
        const { module, clientName, status, currentStatusStage } = data.payload;
        const response = yield call(proceedForAllocationService, clientName, module, status);
        if (status === "Y") {
            yield put(setCurrentStatusStage("Sanity"));
            yield put(setAllocationStatus("INPROGRESS"));
            yield call(delay, 9000);
            yield call(getPerformanceAllocationStatus, data);
        }
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error?.message}));
    }
}

function* proceedForAnalytics(data) {
    try {
        const { module, clientName, status } = data.payload;
        const response = yield call(proceedForAnalyticsService, clientName, module, status);
        yield call(delay, 9000);
        yield call(getPerformanceAllocationStatus, data);
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error?.message}));
    }
}

function* watchGetVarianceIdentificationData() {
    yield takeEvery("GET_VARIENCE_IDENTIFICATION_DATA_ACTION", getVarianceIdentificationData);
}

function* watchSaveVarianceIdentificationData() {
    yield takeEvery("SAVE_VARIENCE_IDENTIFICATION_DATA_ACTION", saveVarianceIdentificationData);
}

function* watchUpdateVarianceIdentificationData() {
    yield takeEvery("UPDATE_VARIENCE_IDENTIFICATION_DATA_ACTION", updateVarianceIdentificationData);
}

function* watchGetVarianceAllocationData() {
    yield takeEvery("GET_VARIENCE_ALLOCATION_DATA_ACTION", getVarianceAllocationData);
}

function* watchSaveVarianceAllocationData() {
    yield takeEvery("SAVE_VARIENCE_ALLOCATION_DATA_ACTION", saveVarianceAllocationData);
}

function* watchAllocationStatusData() {
    yield takeEvery("GET_ALLOCATION_STATUS_ACTION", getPerformanceAllocationStatus);
}

function* watchProceedForAllocation() {
    yield takeEvery("PROCEED_FOR_ALLOCATION_ACTION", proceedForAllocation);
}

function* watchProceedForAnalytics() {
    yield takeEvery("PROCEED_FOR_ANALYTICS_ACTION", proceedForAnalytics);
}

export default function* VarianceDataManagementSaga() {
    yield all([
        watchGetVarianceIdentificationData(),
        watchSaveVarianceIdentificationData(),
        watchUpdateVarianceIdentificationData(),
        watchGetVarianceAllocationData(),
        watchSaveVarianceAllocationData(),
        watchSaveVarianceAllocationData(),
        watchAllocationStatusData(),
        watchProceedForAllocation(),
        watchProceedForAnalytics()
    ]);
}
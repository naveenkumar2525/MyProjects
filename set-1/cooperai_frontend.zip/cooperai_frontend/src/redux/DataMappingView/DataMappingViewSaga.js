import { call, put, takeEvery, all } from 'redux-saga/effects';
import { SNACKBAR_ERROR, SNACKBAR_SUCCESS } from '../GlobalSlices/snackbar';
import { downloadLogReportService, getAPAnalyticsStatusService, getFieldMappingStatusService, getModuleFieldsMappingDataService, saveConfigMappingService, updateConfigMappingService } from './DataMappingViewService';
import { setCurrentStatusStage, setErrorFileDetails, setFieldErrorState, setFieldMappingStatus, setFieldRequestedState, setFieldSuccessState, setModuleFieldsMappingData, statusStagesMapping } from './DataMappingViewSlice';

function* getModuleFieldsMapping(data) { 
    try {
        const response = yield call(getModuleFieldsMappingDataService, data.payload);
        yield put(setModuleFieldsMappingData(response));
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error.message}));
    }
}

function* saveConfigMapping(data) {    
    const { body, clientName, module, currentTableName } = data.payload;
    try {
        yield put(setFieldRequestedState());
        const response = yield call(saveConfigMappingService, body, clientName, currentTableName);
        if (module === "Vendor_module" && currentTableName === "Spend_Cube") {
            yield put(SNACKBAR_SUCCESS("Mappings Saved Successfully"));
            yield put(setFieldSuccessState());
        } else {
            yield call(delay, 9000);
            yield call(getModuleFieldsMappingStatus, { payload: data.payload });
        }
    } catch (error) {
        yield put(setErrorFileDetails(error));
        yield put(SNACKBAR_ERROR({message: error.message}));
    }
}

function* updateConfigMapping(data) {    
    const { body, clientName, module, currentTableName } = data.payload;
    try {
        yield put(setFieldRequestedState());
        const response = yield call(updateConfigMappingService, body, clientName, currentTableName);
        if (module === "Vendor_module" && currentTableName === "Spend_Cube") {
            yield put(setCurrentStatusStage("Initial"));
            yield put(SNACKBAR_SUCCESS("Mappings Saved Successfully"));
            yield put(setFieldSuccessState());
        } else {
            yield call(delay, 9000);
            yield call(getModuleFieldsMappingStatus, { payload: data.payload } )
        }
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error.message}));
    }
}

function* downloadLogFileReport(data) {
    const { fileName, bucketName } = data.payload;
    try {
        const response = yield call(downloadLogReportService, bucketName, fileName);
        const url = window.URL.createObjectURL(response);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', fileName);
        // Append to html link element page
        document.body.appendChild(link);
        // Start download
        link.click();
        // Clean up and remove the link
        link.parentNode.removeChild(link);
    } catch (error) {
       yield put(SNACKBAR_ERROR({message: error}));
    }
}

const delay = time => new Promise(resolve => setTimeout(resolve, time));

function* getModuleFieldsMappingStatus(data) {
    try {
        const { module, clientName, currentStatusStage } = data.payload;
        const response = yield call(getFieldMappingStatusService, module, clientName, currentStatusStage);
        yield put(setFieldMappingStatus(response));

        if (response.status === "ERROR") {
            yield put(setFieldErrorState());
            yield put(setErrorFileDetails(response));
            yield put(SNACKBAR_ERROR({message: "Error Found", action: true, stopAutoHide: true}));
            yield put(setCurrentStatusStage("Initial"));
        } else if (response.status === "SUCCESS") {
            if (statusStagesMapping[module][currentStatusStage] === "Initial") {
                yield put(SNACKBAR_SUCCESS("Mappings Saved Successfully"));
            }
            yield put(setFieldSuccessState());
            yield put(setCurrentStatusStage(statusStagesMapping[module][currentStatusStage]));
        } else if (response.status === "EXCEPTION" || response.status === "error") {
            yield put(setFieldErrorState());
            yield put(SNACKBAR_ERROR({message: "Internal Exception Occured"}));
            yield put(setCurrentStatusStage("Initial"));
        }
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error.message}));
    }
}

function* getAPAnalyticsStatus(data) {
    const { clientName, module } = data.payload;
    try {
        const response = yield call(getAPAnalyticsStatusService, clientName, module);
        yield put(setFieldRequestedState());
        yield call(delay, 9000);
        yield call(getModuleFieldsMappingStatus, { payload: data.payload } );
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error.message}));
    }
}

function* watchGetModuleFieldsMappingt() {
    yield takeEvery("GET_MODULE_FIELDS_MAPPING_ACTION", getModuleFieldsMapping);
}

function* watchSaveMappingRequest() {
    yield takeEvery("SAVE_MAPPING_ACTION", saveConfigMapping);
}

function* watchUpdateMappingRequest() {
    yield takeEvery("UPDATE_MAPPING_ACTION", updateConfigMapping);
}

function* watchDownloadLogFileReport() {
    yield takeEvery("DOWNLOAD_ERROR_LOG_ACTION", downloadLogFileReport);
}

function* watchGetMappingStatus() {
    yield takeEvery("GET_MAPPING_STATUS", getModuleFieldsMappingStatus);
}

function* watchGetAPAnalyticsStatus() {
    yield takeEvery("GET_AP_ANALYTICS_STATUS", getAPAnalyticsStatus);
}

export default function* DataMappingViewSaga() {
    yield all([
        watchGetModuleFieldsMappingt(),
        watchSaveMappingRequest(),
        watchUpdateMappingRequest(),
        watchDownloadLogFileReport(),
        watchGetMappingStatus(),
        watchGetAPAnalyticsStatus()
    ]);
}
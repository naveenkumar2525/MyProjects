import { xhrClient } from './../../utilities/DataRequest';

const getModuleFieldsMappingDataService = (data) => {
    return xhrClient.get(`/api/v1/onboard/fieldMapping/${data.module}/${data.clientName}`);
}

const saveConfigMappingService = (data, clientName, tableName) => {
    return xhrClient.post(`/api/v1/onboard/save/${clientName}?tableName=${tableName}`, null, data);
}

const updateConfigMappingService = (data, clientName, tableName) => {
    return xhrClient.put(`/api/v1/onboard/update/${clientName}?tableName=${tableName}`, null, data);
}

const downloadLogReportService = (bucketName, fileName) => {
    return xhrClient.get(`/api/v1/onboard/download?fileName=${fileName}&bucketName=${bucketName}`, 'text/plain', null, 'blob');
}

const getFieldMappingStatusService = (module, client, process) => {
    return xhrClient.get(`/api/v1/onboard/status/${module}/${client}/${process}`);
}

const getAPAnalyticsStatusService = (client, module) => {
    return xhrClient.get(`/api/v1/variance/data/apanalytics/${client}/${module}`);
}

export {
    getModuleFieldsMappingDataService,
    saveConfigMappingService,
    updateConfigMappingService,
    downloadLogReportService,
    getFieldMappingStatusService,
    getAPAnalyticsStatusService
};

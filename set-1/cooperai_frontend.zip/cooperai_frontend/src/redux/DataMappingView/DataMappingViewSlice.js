import { createSlice } from '@reduxjs/toolkit';

var initialState = {
  clientDatasets: [],
  cooperDatasets: [],
  initialData: true,
  module: 'Org_module',
  postMappingFieldRequested: false,
  postMappingFieldFailed: false,
  postMappingFieldSuccess: false,
  fileName: '',
  bucketName: '',
  currentScreenId: 0,
  tabValues: [],
  currentStatusStage: "Initial"
}

let marginModuleTabs = [
  {
      id: 0,
      name: "Sales Order Data",
  },
  {
      id: 1,
      name: "Cost Data",
  },
  {
      id: 2,
      name: "Join Fields",
  }
]

let vendorModuleTabs = [
  {
      id: 0,
      name: "Spend Cube",
      tableName: "Spend_Cube"
  },
  {
      id: 1,
      name: "Accounts Payable",
      tableName: "Accounts_Payable"
  }
]

let tabHeadersGroup = {
    'Margin_module': marginModuleTabs,
    'Vendor_module': vendorModuleTabs,
}

let tempPnLElement = {
  "clientColumnName": "",
  "clientDataType": "nvarchar(1000)",
  "clientModule": "p&l module",
  "clientName": "client1",
  "cooperColumn": "",
  "cooperDataType": "nvarchar(1000)",
  "dimensions": false,
  "mandate": false,
  "moduleName": "p&l module",
  "tableName": "P&L Join"
}

let tempMarginJoinElement = {
  "cooperColumn": "",
  "cooperDataType": "",
  "dimensions": false,
  "moduleName": "Margin_module",
  "clientColumnName": "",
  "clientModule": null,
  "clientDataType": "",
  "tableName": "Sales_Cost_Join",
  "id": null,
  "clientName": '',
  "mandate": false
}

const joinTables = ['P&L Join', 'Sales_Cost_Join']
const modulesWithJoins = ['p&l module', 'Margin_module']
const emptyJoinElemMap = { 'p&l module': tempPnLElement, 'Margin_module': tempMarginJoinElement }
const moduleTables = {
  'p&l module': ['P&L Input', 'P&L Mapping', 'P&L Join'],
  'Margin_module': ['Sales_Order_Data', 'Cost_Data', 'Sales_Cost_Join', null],
  'Vendor_module': ['Spend_Cube', 'Accounts_Payable']
}
const getOrderedArrayFromDataSet = ({ moduleTables = {}, module = '', dataSet }) => {
  return [...moduleTables[module]?.map(tableName => dataSet
    ?.filter(val => val?.tableName == tableName))].flat()
}

const statusMappping1 = {
  "Initial": "Field Mapping",
  "Field Mapping": "Initial",
}

const statusMappping2 = {
  "Initial": "Field Mapping",
  "Field Mapping": "Analytics",
  "Analytics": "Initial"
}

export const statusStagesMapping = {
  'p&l module': statusMappping1, 
  'Org_module': statusMappping1,
  'Margin_module': statusMappping1,
  'Vendor_module': statusMappping2,
}

const dataMappingViewSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setModuleFieldsMappingData(state, action) {
      let cooperDatasets = action.payload.cooperDatasets.map((v) => { return { ...v, clientDataType: v.clientDataType ? v.clientDataType : "nvarchar(1000)" } })
      state.clientDatasets = action.payload.clientDatasets;
      state.initialData = action.payload.initialData
      let hasJoinElements = cooperDatasets?.filter(val => joinTables.includes(val.tableName)).length > 0
      if (modulesWithJoins.includes(state.module) && action.payload.initialData && !hasJoinElements) {
        let _clientName = cooperDatasets[0]?.clientName
        let _tempPnLElement = { ...emptyJoinElemMap[state.module], clientName: _clientName }
        cooperDatasets = [...getOrderedArrayFromDataSet({ moduleTables, module: state.module, dataSet: cooperDatasets }),
          _tempPnLElement]
      }
      if (modulesWithJoins.includes(state.module) && ((action.payload.initialData && hasJoinElements)
        || !action.payload.initialData)) {
        cooperDatasets = getOrderedArrayFromDataSet({ moduleTables, module: state.module, dataSet: cooperDatasets })
      }
      state.tabValues = tabHeadersGroup[state.module];
      state.cooperDatasets = cooperDatasets;
    },
    setModule(state, action) {
      state.module = action.payload;
    },
    setFieldRequestedState(state, action) {
      state.postMappingFieldRequested = true;
      state.postMappingFieldFailed = false;
      //state.postMappingFieldSuccess = false;
    },
    setFieldErrorState(state, action) {
      state.postMappingFieldFailed = true;
      state.postMappingFieldRequested = false;
      //state.postMappingFieldSuccess = false;
    },
    setFieldSuccessState(state, action) {
      state.postMappingFieldFailed = false;
      state.postMappingFieldRequested = false;
      //state.postMappingFieldSuccess = true;
    },
    setErrorFileDetails(state, action) {
      state.fileName = action.payload.fileName;
      state.bucketName = action.payload.bucketName;
    },
    setCurrentScreenId(state, action) {
      if (action.payload != undefined || action.payload != null) {
        state.currentScreenId = action.payload && action.payload;
      }
    },
    setFieldMappingStatus(state, action) {
      state.postMappingFieldSuccess = action.payload.status;
    },
    setUniqueFieldData(state, action) {
      state.cooperDatasets = action.payload.cooperDatasets;
    },
    setCurrentStatusStage(state, action) {
      state.currentStatusStage = action.payload;
    },
  },
})

export default dataMappingViewSlice.reducer;

//Actions
export const {
  setModuleFieldsMappingData,
  setModule,
  setFieldRequestedState,
  setFieldErrorState,
  setFieldSuccessState,
  setErrorFileDetails,
  setCurrentScreenId,
  setFieldMappingStatus,
  setUniqueFieldData,
  setIndividualTabData,
  setCurrentStatusStage
} = dataMappingViewSlice.actions;
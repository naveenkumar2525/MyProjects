import { all } from 'redux-saga/effects';
import AuthManagementSaga from './AuthManagement/AuthManagementSaga';
import DataMappingViewSaga from './DataMappingView/DataMappingViewSaga';
import VarianceDataManagementSaga from './VarianceDataManagement/VarianceDataManagementSaga';

function* rootSaga() {
    yield all([
        AuthManagementSaga(),
        DataMappingViewSaga(),
        VarianceDataManagementSaga()
    ]);
}

export default rootSaga;
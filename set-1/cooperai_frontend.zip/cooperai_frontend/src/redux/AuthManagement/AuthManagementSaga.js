import { call, put, takeEvery, all } from 'redux-saga/effects';
import jwt from 'jwt-decode';
import {
    loginSucceeded, loginFailed } from './AuthManagementSlice';
import {
    signInService,sigUpService
} from './AuthManagementService';
import { SNACKBAR_ERROR,SNACKBAR_SUCCESS } from '../GlobalSlices/snackbar';

function* login(data) {
    const { values, navigate, keepMeSignedIn } = data.payload;
    const options = {
        emailId: values.email,
        password: values.password
    };
    try {
        const response = yield call(signInService, options);
        const { access_token } = response.result;
        const user = jwt(access_token);
        yield put(loginSucceeded({user: user.sub, accessToken: access_token}));
        navigate('/home');
        if (keepMeSignedIn) {
            localStorage.setItem('accessToken', access_token);
        } else {
            sessionStorage.setItem('accessToken', access_token);
        }
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error.message}));
        yield put(loginFailed(error));
        localStorage.removeItem('accessToken');
    }
}

function* signup(data) {
    const { values, navigate } = data.payload;
    const {email:emailId,firstname:firstName,lastname:lastName,password}=values
    const params={emailId,firstName,lastName,password}
    const options = {...params};
    try {
        const response = yield call(sigUpService, options);
        yield put(SNACKBAR_SUCCESS(response?.message));
        navigate('/login');
    } catch (error) {
        yield put(SNACKBAR_ERROR({message: error?.message}));
    }
}

function* watchLoginRequest() {
    yield takeEvery("LOGIN_REQUEST_ACTION", login);
}

function* watchSignupRequest() {
    yield takeEvery("SIGNUP_REQUEST_ACTION", signup);
}

export default function* authManagementSaga() {
    yield all([
        watchLoginRequest(),watchSignupRequest()
    ]);
}
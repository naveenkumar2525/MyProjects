import { createSlice } from '@reduxjs/toolkit';

const token = localStorage.getItem('authToken')? 
                localStorage.getItem('authToken'): 
                    sessionStorage.getItem('authToken');

var initialState = {
   keepMeSignedIn: false,
   user: '',
   authToken: token,
   error: false
}

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        setSignedInState(state, action) {
            state.keepMeSignedIn = action.payload;
        },
        loginSucceeded(state, action) {
            state.authToken = action.payload.accessToken;
            state.user = action.payload.user;
        },
        loginFailed(state, action) {
            state.error = true;
            state.user = {};
        }
    },
})

export default authSlice.reducer;

//Actions
export const {
    setSignedInState, loginSucceeded, loginFailed
} = authSlice.actions;
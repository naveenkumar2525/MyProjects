import { xhrClient } from './../../utilities/DataRequest';

const signInService = (data) => {
    return xhrClient.post(`/api/v1/user/login`, null, data);
}

const sigUpService = (data) => {
    return xhrClient.post(`/api/v1/user/signup`, null, data);
}
export {
    signInService,sigUpService
};

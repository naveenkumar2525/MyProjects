import { combineReducers } from 'redux';
import storage from 'redux-persist/lib/storage';
import DataMappingViewReducer from './DataMappingView/DataMappingViewSlice';
import AuthReducer from './AuthManagement/AuthManagementSlice';
import VarianceDataManagementReducer from './VarianceDataManagement/VarianceDataManagementSlice';
import SnackbarReducer from './GlobalSlices/snackbar';

// ----------------------------------------------------------------------

const rootPersistConfig = {
  key: 'root',
  storage: storage,
  keyPrefix: 'redux-',
  whitelist: ['settings'],
};

const rootReducer = combineReducers({
  SnackbarReducer: SnackbarReducer,
  auth: AuthReducer,
  dmv: DataMappingViewReducer,
  vdm: VarianceDataManagementReducer
});

export { rootPersistConfig, rootReducer };
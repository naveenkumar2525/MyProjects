import React from 'react';
import { Badge, Grid, IconButton, InputBase, Typography, Tooltip } from '@mui/material';
import { styled, alpha } from '@mui/material/styles';
import Avatar from '@mui/material/Avatar';
import SearchIcon from '@mui/icons-material/Search';
import NotificationsNoneOutlinedIcon from '@mui/icons-material/NotificationsNoneOutlined';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import MicNoneIcon from '@mui/icons-material/MicNone';
import Logo from './../assets/logo_cooper_thinner.png';
import CLink from '../components/atoms/CLink';
import ProfileImage from './../assets/zahir-namane-hwc7eIQiTCE-unsplash.png';

////////////////////////////////////////////////////////////////////////////

const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
    },
}));
  
const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'rgba(0, 0, 0, 0.4)'
}));
    
const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'rgba(0, 0, 0, 0.4)',
    height: '100%',
    '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
        width: '12ch',
        '&:focus': {
        width: '20ch',
        },
    },
    },
}));
  
///////////////////////////////////////////////////////////////////////////////

export default function Header({ isLogin = true }) {
    const accessToken = localStorage.getItem("accessToken");
    const sessionToken = sessionStorage.getItem("accessToken");
   
    return(
        <header>
            { (!accessToken || !sessionToken)
            ?
            <Grid style={{ width:'100%'}} p={2} display="flex" justifyContent="space-between">
                <Grid>
                    <img
                        src={Logo}
                        alt="logo"
                        loading="lazy"
                    />
                </Grid>
                <Grid display="flex" alignItems={"center"}>
                    <Search sx={{ height: '40px', backgroundColor: '#20314B1F'}}>
                        <SearchIconWrapper>
                        <SearchIcon />
                        </SearchIconWrapper>
                        <StyledInputBase
                            placeholder="Search"
                            inputProps={{ 'aria-label': 'search' }}
                        />
                    </Search>
                    <IconButton
                        size="large"
                        aria-label="account of current user"
                        color="inherit"
                        sx={{ ml: 2}}
                    >
                        <MicNoneIcon sx={{ color: 'rgba(0, 0, 0, 0.4)' }}/>
                    </IconButton>
                    <IconButton size="large" aria-label="show 4 new mails" color="inherit" sx={{ ml: 2}}>
                        <Badge>
                            <HelpOutlineIcon sx={{ color: 'rgba(0, 0, 0, 0.4)' }}/>
                        </Badge>
                    </IconButton>
                    <IconButton
                        size="large"
                        aria-label="show 17 new notifications"
                        color="inherit"
                        sx={{ ml: 2}}
                    >
                        <Badge color="success">
                            <NotificationsNoneOutlinedIcon sx={{ color: '#000'}}/>
                        </Badge>
                    </IconButton>
                    <Tooltip title="Profile">
                        <IconButton sx={{ p: 0, ml: 2 }}>
                            <Avatar alt="Remy Sharp" src={ProfileImage} />
                        </IconButton>
                    </Tooltip>
                </Grid>
            </Grid>
            :
            <Grid style={{ width:'100%'}} p={2} display="flex" justifyContent="space-between">
                <Grid>
                    <img
                        src={Logo}
                        alt="logo"
                        loading="lazy"
                    />
                </Grid>
                <Grid display="flex">
                    <Typography sx={{ color: '#fff'}}>{isLogin ? 'Don\'t have an account?' : 'Already have an account?'}</Typography>
                    <CLink to={isLogin?'/register':'Login'} variant="subtitle1" label={isLogin?"Sign Up":"Sign In"}/>
                </Grid>
            </Grid>
            }
        </header>
    )
}
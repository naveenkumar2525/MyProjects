import React from 'react';

export default function Prompt(props){
    return(
        <h5 className="prompt" style={{color: props.color}}>{props.prompt}</h5>
    )
}
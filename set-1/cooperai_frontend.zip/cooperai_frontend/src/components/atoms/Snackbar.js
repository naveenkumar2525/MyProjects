import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Snackbar, SnackbarContent, IconButton, Button } from '@mui/material';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import CloseIcon from '@mui/icons-material/Close';
import { SNACKBAR_CLEAR } from './../../redux/GlobalSlices/snackbar';

// success
const SuccessSnackbar = () => {
    const dispatch = useDispatch();
    const { successSnackbarMessage, successSnackbarOpen } = useSelector(
        (state) => state.SnackbarReducer
    );
    
    function handleClose() {
        dispatch({ type: SNACKBAR_CLEAR.type });
    }

    return (
        <Snackbar
            anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
            }}
            open={successSnackbarOpen}
            autoHideDuration={4000}
            onClose={handleClose}
            aria-describedby='client-snackbar'
            >
            <SnackbarContent
                style={{
                    backgroundColor: '#4DBEAC',
                }}
                message={
                <span
                    id='client-snackbar'
                    style={{ verticalAlign: 'middle', display: 'inline-flex' }}
                >
                    <span>
                        <CheckCircleOutlineIcon />
                    </span>
                    <span style={{ marginLeft: 15 }}>{successSnackbarMessage}</span>
                </span>
                }
                action={[
                    <IconButton
                        key='close'
                        aria-label='close'
                        color='inherit'
                        onClick={handleClose}
                        className='pb-5'
                    >
                        <CloseIcon />
                    </IconButton>
                ]}
            />
        </Snackbar>
    );
}

//Error

const ErrorSnackbar = () => {
    const dispatch = useDispatch();
    const { fileName, bucketName } = useSelector((state) => state.dmv);
    const { errorSnackbarContent, errorSnackbarOpen } = useSelector(
        (state) => state.SnackbarReducer
    );
    
    function handleClose() {
        dispatch({ type: SNACKBAR_CLEAR.type });

        if (errorSnackbarContent && errorSnackbarContent.action) {
            dispatch({
                type: "DOWNLOAD_ERROR_LOG_ACTION",
                payload: { 
                    fileName,
                    bucketName
                }
            })
        } 
    }

    return (
        <Snackbar
            anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
            }}
            open={errorSnackbarOpen}
            autoHideDuration={errorSnackbarContent?.stopAutoHide? null: 4000}
            onClose={handleClose}
            aria-describedby='client-snackbar'
            >
            <SnackbarContent
                style={{
                // backgroundColor: '#D3302F'
                backgroundColor: '#000',
                color: 'red'
                }}
                message={
                <span
                    id='client-snackbar'
                    style={{ verticalAlign: 'middle', display: 'inline-flex' }}
                >
                    <span style={{ marginLeft: 15 }}>{errorSnackbarContent?.message}</span>
                </span>
                }
                handleClose={handleClose}
                // action={errorSnackbarContent?.action? errorSnackbarContent.action: null}
                action={  errorSnackbarContent?.action?
                    <React.Fragment>
                        <Button color="primary" size="small" onClick={handleClose}>
                            DOWNLOAD
                        </Button>
                        <IconButton
                            size="small"
                            aria-label="close"
                            onClick={handleClose}
                            sx={{ color: '#FFF' }}
                        >
                            <CloseIcon fontSize="small" color="#FFF" />
                        </IconButton>
                    </React.Fragment>: null
                }
            />
        </Snackbar>
    );
}


export {SuccessSnackbar, ErrorSnackbar};
import { TextField, IconButton, InputAdornment } from '@mui/material';
import React, { useState } from 'react';
import { styled } from '@mui/system';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

const StyledTextField = styled(TextField)(() => ({
    '& label.Mui-focused': {
        color: '#4DBEAC',
        borderColor: "#4DBEAC",
    },
    '& .MuiFormLabel-root': {
        borderWidth: '5px',
        borderColor: '#4DBEAC !important',
        color: 'rgba(255, 255, 255, .3)'
    },
    '& .MuiInput-underline:after': {
        borderBottomColor: "#4DBEAC",
    },
    '& .MuiOutlinedInput-root': {
        '&.Mui-focused fieldset': {
            borderColor: "#4DBEAC",
        },
        '&:hover fieldset': {
            borderColor: "#4DBEAC",
        }
    },
    '& .MuiOutlinedInput-notchedOutline': {
        border: '0.1px solid rgba(255, 255, 255, .3)'
    },
    '& .MuiOutlinedInput-input': {
        color: '#fff'
    }
}))

const validationCheck = (fieldName, value) => {
    let re;
    if (fieldName === 'email') {
        re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        if (value && re.test(value)) {
            return false;
        }
        else {
            return 'Invalid email format';
        }
    } else
        if (fieldName === 'password') {
            re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            if (value && re.test(value)) {
                return false;
            }
            else {
                return 'Password is Minimum eight characters, at least one uppercase letter, one lowercase letter and one number'
            }
        }

}

export default function FormInput(props) {
    const { fail } = props;
    const [touched, setTouched] = useState(false);

    const handleTouch = () => {
        setTouched(true);
    };
    return (
        <StyledTextField
            type={props.type}
            className={`input ${fail ? "input--fail" : null} `}
            sx={{ mt: 4 }}
            placeholder={props.placeholder}
            name={props.name}
            value={props.value}
            onChange={props.handleChange}
            onKeyDown={props.handleKeyDown}
            size="small"
            label={props.label ?? props.name}
            color="success"
            InputProps={{
                endAdornment: props.endAdornment ?
                    <InputAdornment position="end">
                        <IconButton
                            aria-label="toggle password visibility"
                            onClick={props.handleClickShowPassword}
                            onMouseDown={props.handleMouseDownPassword}
                            edge="end"
                        >
                            {!props.showPassword ? <VisibilityOff sx={{ color: 'rgba(255, 255, 255, 0.5)' }} /> : <Visibility sx={{ color: 'rgba(255, 255, 255, 0.5)' }} />}
                        </IconButton>
                    </InputAdornment> : null
            }}
            onFocus={() => handleTouch()}
            // onBlur={()=>setTouched(false)}
            error={touched && validationCheck(props.name, props.value)}
            helperText={touched && validationCheck(props.name, props.value)}
        />
    )
}



import * as React from 'react';
import { 
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Typography
} from "@mui/material";

export default function DialogComponent({
    title = "",
    isDialogueOpen,
    dialogueHeader,
    dialogueSubject,
    handleClose,
    showProgress,
    dialogueActions,
    dialogueSubjectHeader
  }) {
  return (
    <div>
      <Dialog
        open={isDialogueOpen}
        keepMounted
        onClose={handleClose}
        aria-describedby="alert-dialog-slide-description"
        PaperProps={{
            sx: {
              width: '400px',
              minHeight: 100,
              padding: '10px',
              textAlign: 'center'
            }
        }}
      >
        { title ? <DialogTitle>{title}</DialogTitle>: null }
        <DialogContent>
          { showProgress && <CircularProgress /> }
          <Typography variant='h5' sx={{ mt: 1, color: 'rgba(0, 0, 0, 0.7)' }}>
              <b>{dialogueHeader}</b>
          </Typography>
          <Typography variant='button' sx={{ mt: 1, color: 'rgba(0, 0, 0, 0.7)' }}>
              <b>{dialogueSubjectHeader}</b>
          </Typography>
          <Typography 
              variant='body2'
              sx={{ mt: 1 }}
          >
              {dialogueSubject}
          </Typography>
        </DialogContent>

        <DialogActions>
          { dialogueActions }
        </DialogActions>
      </Dialog>
    </div>
  );
}
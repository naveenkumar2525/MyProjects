import * as React from 'react';
import { styled } from '@mui/system';
import { makeStyles } from '@mui/styles';
import { FormControl, InputLabel, MenuItem, Paper, Select } from '@mui/material';
import ExpandMoreOutlinedIcon from '@mui/icons-material/ExpandMoreOutlined';

//////////////////////////////////////////////////////////////////////////

const useStyles = makeStyles({
  select: {
      "& ul": {
          backgroundColor: "#fff",
          color: "#000",
          border: "1px solid #4DBEAC"
      },
      "& li": {
          fontSize: 12,
      },
  },
});

const StyledSelectField = styled(Select)(() => ({
    '& label.Mui-focused': {
        color: '#4DBEAC',
        borderColor: "#4DBEAC",
    },
    '& .MuiFormLabel-root': {
        borderWidth: '5px',
        borderColor: '#496590 !important',
        color: 'rgba(255, 255, 255, .3)'
    },
    '& .MuiInput-underline:after': {
        borderBottomColor: "#4DBEAC",
    },
    '& .MuiOutlinedInput-root': {
        '&.Mui-focused fieldset': {
            borderColor: "#4DBEAC",
        },
        '&:hover fieldset': {
            borderColor: "#4DBEAC",
        }
    },
    '& .MuiOutlinedInput-notchedOutline': {
        border: '0.1px solid #496590'
    },
    '& .MuiOutlinedInput-input': {
        color: '#000'
    },
    '& .MuiFormLabel-root-MuiInputLabel-root': {
        color: '#000'
    },
    '& .MuiSelect-icon': {
       color: '#000'
    }
}))

//////////////////////////////////////////////////////////////////////////

export default function DropDown({ label, selectedValue, values, emptyText="None", handleChange, disable }) {
  const classes = useStyles();
  return (
    <FormControl size="small" sx={{ width: '100%', mt: 4}}>
      <InputLabel sx={{ color: 'rgba(255, 255, 255, .3)'}} id="dropdown-small">{label}</InputLabel>
      <StyledSelectField
        labelId="dropdown-small"
        id="dropdown-small"
        value={selectedValue}
        label={label}
        onChange={handleChange}
        MenuProps={{ classes: { paper: classes.select } }}
        IconComponent={ExpandMoreOutlinedIcon}
      >
        <MenuItem value="" disabled={disable}>
          <em>{emptyText}</em>
        </MenuItem>
        {
            values?.map((item) =>
                <MenuItem value={item.value}>{item.name}</MenuItem>
            )
        }
      </StyledSelectField>
    </FormControl>
  );
}
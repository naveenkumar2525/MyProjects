import { Typography, Link } from '@mui/material';
import React from 'react';

export default function CLink(props) {
    const { fail } = props;
    return(
        <Link href={props.to} underline="none">
            <Typography variant={'subtitle2'} color="#4DBEAC" sx={{ ml: 1}}>
                {props.label}
            </Typography>
        </Link>
    )
}
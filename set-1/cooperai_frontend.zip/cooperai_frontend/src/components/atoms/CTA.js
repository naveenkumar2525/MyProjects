import React from 'react';
import { Button } from '@mui/material';
import { makeStyles } from '@mui/styles';

/////////////////////////////////////////////////////////////////////

const useStyles = makeStyles({
    disabledButton: {
        backgroundColor: 'rgba(0, 0, 0, 0.1) !important',
        color: 'rgba(0, 0, 0, 0.6) !important'
    },
  });
  
/////////////////////////////////////////////////////////////////////

export default function CTA(props) {
    const classes = useStyles();
    return (
        <Button className={`btn ${props.isDisabled ? classes.disabledButton : ''}`} style={props.styles} type={props.type} disabled={props.isDisabled} onSubmit={props.handleSubmit}
            onClick={props.onClick}
        >
            <h4>{props.name}</h4>
        </Button>
    )
}

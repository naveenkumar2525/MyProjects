import React, { useEffect } from 'react';
import { Button, Grid } from "@mui/material";
import CTA from "../../atoms/CTA";
import DataColWrap from "../../molecules/DataColWrap";
import VarianceDataRow from '../../molecules/VarianceDataRow';
import { useNavigate, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { setVarianceData } from '../../../redux/VarianceDataManagement/VarianceDataManagementSlice';
import { setModule } from '../../../redux/DataMappingView/DataMappingViewSlice';

const VarianceDataList = () => {
    const { clientName } = useParams();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { varianceIdentificationData, masterData, plValues, initialData } = useSelector((state) => state.vdm);
    
    useEffect(() => {
        dispatch({
            type: "GET_VARIENCE_IDENTIFICATION_DATA_ACTION",
            payload: clientName
        });
    }, [])

    const handleChange = (index, name, value) => {
        let newData = JSON.parse(JSON.stringify(varianceIdentificationData));
        newData[index][name] = value;

        dispatch({
            type: setVarianceData.type,
            payload: newData
        })
    }
    const addField = () => {
        let newData = JSON.parse(JSON.stringify(varianceIdentificationData));
        let l = newData.length
        let variantElement = {
            "id": l + 1,
            "category": `Cost Bucket ${l}`,
            "plValue": null,
            "masterDataValue": null,
            "client": clientName
        }

        dispatch({
            type: setVarianceData.type,
            payload: [...newData,variantElement]
        })
    }

    const handleSubmit = () => {
        if (initialData) {
            dispatch({
                type: "SAVE_VARIENCE_IDENTIFICATION_DATA_ACTION",
                payload: { varianceIdentificationData, clientName, navigate}
            });
        } else {
            dispatch({
                type: "UPDATE_VARIENCE_IDENTIFICATION_DATA_ACTION",
                payload: { varianceIdentificationData, clientName, navigate}
            });
        }
    }

    const handleReset = () => {
        dispatch({
            type: "GET_VARIENCE_IDENTIFICATION_DATA_ACTION",
            payload: clientName
        });
    }

    return (
        <Grid container display="flex" justifyContent="flex-start" alignItems={"center"} xs={12}>
            <Grid display="flex" xs={12} sx={{ mt: 0, pb: 1, backgroundColor: 'rgba(4, 179, 242, 0.04)', borderBottom: '2px solid #ccc' }}>
                <DataColWrap> <span className="head-list">Category</span></DataColWrap>
                <DataColWrap> <span className="head-list">P&L Value</span></DataColWrap>
                <DataColWrap> <span className="head-list" style={{ marginLeft: "1.5rem" }}>Master Data Value</span></DataColWrap>
                <DataColWrap> <Grid container display="flex" justifyContent="flex-end" alignItems="center" sx={{ ml: "-3rem" }}>
                    <Button variant='outlined' onClick={addField}>ADD FIELD</Button></Grid> </DataColWrap>
            </Grid>
            <Grid item xs={12}>
                <Grid container sx={{ height: '50vh', overflowX: 'hidden' }} spacing={0}>
                    {varianceIdentificationData?.map((data, index) => <VarianceDataRow data={data} plValues={plValues} masterData={masterData} handleChange={(name, value) => handleChange(index, name, value)} />)}
                </Grid>
                <Grid container justifyContent="flex-end">
                    <Grid item xs={2} display="flex" alignItems={"center"} sx={{ pt: 2 }}>
                        <CTA
                            styles={{border: '1px solid #4DBEAC',color: '#4DBEAC', marginRight: '20px'}} 
                            name={"RESET"} 
                            type={"reset"} 
                            onClick={handleReset}
                        />
                        <CTA
                            styles={{ color: '#000', backgroundColor: '#4DBEAC' }}
                            name={"SUBMIT"}
                            type={"submit"}
                            onClick={handleSubmit}
                        />
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    )
}

export default VarianceDataList;
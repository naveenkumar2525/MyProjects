import SunImage from '../../../assets/sunrise.png';
import { Grid, Typography } from '@mui/material';
const SplashScreen = () => {
    return (
        <Grid sx={{ height: '300px'}}>
            <Grid display="flex" justifyContent={"center"}>
                <img src={SunImage} alt="sun_rise" loading="lazy" height="60" width="110"/>
            </Grid>
            <Typography variant='h2' color="#fff" sx={{ mt: 1 }}>Good Morning!</Typography>
            <Typography variant='h6' color="#fff" sx={{ mt: 2 }}>Just a sec while we gather today's decisions...</Typography>
        </Grid>
    )
}
export default SplashScreen;
import React from 'react';
import { Grid } from "@mui/material";
import { useSelector } from 'react-redux';
import './datalist.css';
import GenericListView from '../GenericListView';
import TabsViewHeader from '../../molecules/TabsViewHeader';

const DataList = ({clientName}) => {
    const { module } = useSelector((state) => state.dmv);

    const renderListView = () => {
        if ( ['Margin_module', 'Vendor_module'].includes(module) ) {
            return (<Grid xs={12}>
                <TabsViewHeader />
                <GenericListView clientName={clientName} />
            </Grid>)
        }
        return <GenericListView clientName={clientName}/>
    }

    return (
        <Grid container sx={{
            height: '65vh',
        }} spacing={0} display="flex" justifyContent="flex-start"
            xs={12} >
            {renderListView()}
        </Grid>
    )
}

export default DataList;
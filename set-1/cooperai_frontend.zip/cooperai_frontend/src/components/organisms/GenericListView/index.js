import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Grid, Typography } from "@mui/material";
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import DialogComponent from '../../atoms/Dialogue';
import CTA from '../../atoms/CTA';
import DataRowHeader from '../../molecules/DataRowHeader';
import DataSetRow from '../../molecules/DataSetRow';
import DataColWrap from '../../molecules/DataColWrap';
import { 
    setCurrentScreenId,
    setCurrentStatusStage,
    setModuleFieldsMappingData,
    setUniqueFieldData
} from '../../../redux/DataMappingView/DataMappingViewSlice';

const GenericListView = ({ clientName }) => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [ resetConfirmPopupOpen, setResetConfirmPopupOpen ] = useState(false);
    const { 
        clientDatasets,
        cooperDatasets,
        initialData,
        module,
        postMappingFieldRequested,
        tabValues,
        currentScreenId,
        currentStatusStage } = useSelector((state) => state.dmv);

    const clientDatabaseOptions = Array.from(new Set(clientDatasets?.map((v) => v)))
        ?.map(val => ({ value: val.name, name: val.name, type: val.type ,tableName:val.tableName}));

    const typeMap = {};

    clientDatasets?.map(({ type, dataType }) => {
        typeMap[dataType] = type;
    })

    const inputColumnOptions = [];
    const mappingColumnOptions = [];
    const uniqueIdJoinOptions = [];
    const isHeaderForRowVisible = ['p&l module', 'Margin_module', 'Vendor_module'].includes(module)
    if (isHeaderForRowVisible) {
        clientDatasets?.map(val => {
            if (['P&L Input', 'Sales_Order_Data'].includes(val?.tableName)) {
                inputColumnOptions.push({ value: val.name, name: val.name, type: val.type })
            }
            if (['P&L Mapping', 'Cost_Data'].includes(val?.tableName)) {
                mappingColumnOptions.push({ value: val.name, name: val.name, type: val.type })
            }
            uniqueIdJoinOptions.push({value: val.name, name: val.name})
        })
    }
    const categoryMap = {
        'P&L Input': 'Input File',
        'P&L Join': 'P&L Join Condition',
        'P&L Mapping': 'Mapping File',
        'p&l mapping': 'Mapping File',
        'Sales_Order_Data': 'Sales Order Data',
        'Cost_Data': 'Cost Data',
        'Sales_Cost_Join': 'Join Fields',
        'Spend_Cube': 'Spend Cube',
        'Accounts_Payable': 'Accounts Payable',
        'Unique_Join': 'Unique Id'
    }
    const hasTableNeedButton = {
        'P&L Join': false,
        'P&L Mapping': false,
        'p&l mapping': false,
        'Sales_Order_Data': false,
        'Cost_Data': false,
        'Sales_Cost_Join': true,
        'Unique_Join': true
    }
    const joinRowTitleParams = {
        'Sales_Cost_Join': { left: 'Sales Order Data', right: 'Cost Data' },
        'P&L Join': { left: 'Input Column', right: 'Mapping Column' }
    }
    const marginModuleHeaderData = {
        "Sales Order Data": 0,
        "Cost Data": 1,
        "Join Fields": 2,
        "Unique Id": 3
    }
    const vendorModuleHeaderData = {
        "Spend Cube": 0,
        "Accounts Payable": 1,
    }

    const tabHeaders = {
        "Margin_module": marginModuleHeaderData,
        "Vendor_module": vendorModuleHeaderData,
    }

    let prevTableName = '';
    var tabCount = 0;

    const save = () => {
        dispatch({
            type: setCurrentStatusStage.type,
            payload: "Field Mapping"
        });
        let newDataSet = [...cooperDatasets];
        let currentTableName = "";
        if (module === "Vendor_module") {
            currentTableName = tabValues.find(v=>v.id == currentScreenId)?.tableName;
            newDataSet = newDataSet.filter(v => v.tableName === currentTableName );
        }
        if (initialData) {
            dispatch({
                type: "SAVE_MAPPING_ACTION",
                payload: { body: { fieldMapping: newDataSet }, clientName, module, navigate, currentTableName, currentStatusStage: "Field Mapping"}
            });
        } else {
            dispatch({
                type: "UPDATE_MAPPING_ACTION",
                payload: { body: { fieldMapping: newDataSet }, clientName, module, navigate, currentTableName, currentStatusStage: "Field Mapping" }
            });
        }

    }

    const handleChange = (index, key, value) => {
        let data = JSON.parse(JSON.stringify(cooperDatasets));
        let tempData = data?.map((val, id) => {
            if (id == index) {
                val[key] = value
                return val
            } else {
                return val
            }
        });
        dispatch({
            type: setModuleFieldsMappingData.type,
            payload: { cooperDatasets: tempData, clientDatasets, initialData }
        });
    }

    const addJoinField = (tableName, index) => {
        let data = JSON.parse(JSON.stringify(cooperDatasets));
        if (tableName === "Unique_Join") {
            data[index].clientColumnName = data[index].clientColumnName + "|";
            dispatch({
                type: setUniqueFieldData.type,
                payload: {
                    cooperDatasets: [...data]
                }
            });
        } else {
            let tempMarginJoinElement = {
                "cooperColumn": "",
                "cooperDataType": "",
                "dimensions": false,
                "moduleName": "Margin_module",
                "clientColumnName": "",
                "clientModule": null,
                "clientDataType": "",
                "tableName": tableName,
                "id": null,
                "clientName": clientName,
                "mandate": false
            }
            dispatch({
                type: setModuleFieldsMappingData.type,
                payload: {
                    cooperDatasets: [...data, { ...tempMarginJoinElement }],
                    clientDatasets, initialData
                }
            });
        }
    }
    const validateSaveButton = () => {
        let data = [...cooperDatasets];
        if (module === "Vendor_module") {
            data = data.filter(v=> v.tableName === tabValues?.find(v=>v.id == currentScreenId)?.tableName)
        }
        let validateCheck = data.some((cooperDataItem) => {
            return cooperDataItem.mandate === true &&
                    [null, "", undefined, "|"].includes(cooperDataItem.clientColumnName);
        })
        return validateCheck;
    }

    const ref = useRef()

    let scrolling = false;

    // The scroll listener
    const handleScroll = useCallback((e) => {
        if (["Margin_module", "p&l module"].includes(module)) {
            scrolling = true;
            setInterval(() => {
                if (scrolling) {
                    scrolling = false;
                    let position = e.target.childNodes[Math.round(e.target.scrollTop/(e.target.scrollHeight/e.target.childElementCount)+1)]
                    if (position) {
                        dispatch({
                            type: setCurrentScreenId.type,
                            payload: tabHeaders[module][position.attributes.tableData.value]
                        })
                    }
                }
            }, 10000); 
        }
    }, [module])

    // Attach the scroll listener to the div
    useEffect(() => {
        const div = ref.current
        div.addEventListener("scroll", handleScroll, true)
    }, [handleScroll])

    useEffect(() => {
        if (cooperDatasets.length) {
            prevTableName = cooperDatasets[0].tableName;
        }
    }, [cooperDatasets])

    const handleUniqueIdFieldDelete = (innerIndex, index) => {
        let data = JSON.parse(JSON.stringify(cooperDatasets));
        let newData = data[index].clientColumnName.split("|");
        newData.splice(innerIndex, 1);
        data[index].clientColumnName = newData.join("|");
        dispatch({
            type: setUniqueFieldData.type,
            payload: {
                cooperDatasets: [...data]
            }
        });
    }

    const handleUniqueIdFieldChange = (index, innerIndex, value) => {
        let data = JSON.parse(JSON.stringify(cooperDatasets));
        data[index].clientColumnName = data[index].clientColumnName? data[index].clientColumnName: '';
        let newData = data[index].clientColumnName.split("|");
        newData[innerIndex] = value;
        data[index].clientColumnName = newData.join("|");
        dispatch({
            type: setUniqueFieldData.type,
            payload: {
                cooperDatasets: [...data]
            }
        });
    }

    const reset = () => {
        dispatch({
            type: "GET_MODULE_FIELDS_MAPPING_ACTION",
            payload: { 
                module,
                clientName
            }
        });
        setResetConfirmPopupOpen(false);
    }

    return (
        <Grid xs={12}>
            <Grid display="flex" xs={12} sx={{
                mt: 0, pb: 1, backgroundColor: 'rgba(4, 179, 242, 0.04)',
                borderBottom: '1px solid #ccc'
            }}>
                <DataColWrap> <span className="head-list">Cooper Dataset</span></DataColWrap>
                <DataColWrap>
                    <span className="head-list">Client's Dataset</span>
                </DataColWrap>
            </Grid>
            <Grid item spacing={0}>
                <Grid container sx={{ height: '55vh', overflowX: 'hidden' }} spacing={0} className="scrollableContainer" ref={ref}>
                    {cooperDatasets?.map((data, index) => {
                        const button= data.tableName === 'Sales_Cost_Join' ? 'Sales_Cost_Join' : 'Unique_Join'
                        let node = <Grid container tableData={categoryMap[data.tableName]}>{((isHeaderForRowVisible && prevTableName !== data.tableName) || data.cooperColumn === 'Unique ID') == true &&
                            <DataRowHeader
                                id={tabCount}
                                tableData={categoryMap[data.tableName]}
                                headerName={data.cooperColumn === 'Unique ID'? `${categoryMap[data.tableName] ? categoryMap[data.tableName]: ''} Unique Join`: categoryMap[data.tableName]}
                                shouldShowButton={hasTableNeedButton[data.tableName] || data.cooperColumn === 'Unique ID'}
                                buttonName={data.cooperColumn === 'Unique ID'? 'ADD FIELD' : 'ADD JOIN FIELD'}
                                onClick={()=>addJoinField(button, index)}
                            ></DataRowHeader>}
                            <DataSetRow {...data} typeMap={typeMap}
                                clientDataType={typeMap[data.clientDataType]}
                                handleChange={(key, value) => handleChange(index, key, value)}
                                clientDatabaseOptions={clientDatabaseOptions?.filter(({tableName})=>tableName == data.tableName)}
                                shouldShownJoinRows={['P&L Join', 'Sales_Cost_Join'].includes(data.tableName)}
                                joinRowParams={joinRowTitleParams[data.tableName]}
                                inputColumnOptions={inputColumnOptions}
                                mappingColumnOptions={mappingColumnOptions}
                                key={index}
                                uniqueIdRow={data.cooperColumn === 'Unique ID'}
                                handleUniqueIdFieldDelete={(innerIndex)=>handleUniqueIdFieldDelete(innerIndex, index)}
                                uniqueIdJoinOptions={uniqueIdJoinOptions}
                                handleUniqueIdFieldChange={(innerIndex, value) => handleUniqueIdFieldChange(index, innerIndex, value)}
                            /></Grid>
                        if (prevTableName !== data.tableName) {
                            tabCount++;
                        }
                        prevTableName = data.tableName;
                        if (module === "Vendor_module") {
                            if (data.tableName === tabValues?.find(v=>v.id === currentScreenId)?.tableName) {
                                return node;
                            } else return;
                        }
                        return node;
                    })}
                </Grid>
                <Grid container sx={{ height: '5vh' }} spacing={0} justifyContent="flex-end">
                    <Grid item xs={2} display="flex" alignItems={"center"} sx={{ pt: 2 }}>
                        <CTA
                            styles={{
                                border: '1px solid #4DBEAC',
                                color: '#4DBEAC', marginRight: '20px'
                            }} 
                            name={"RESET"} 
                            type={"submit"}
                            onClick={() => setResetConfirmPopupOpen(true)}
                        />
                        <CTA
                            onClick={() => save()}
                            styles={{ color: '#000', backgroundColor: '#4DBEAC' }}
                            name={"SAVE"}
                            type={"submit"}
                            isDisabled={validateSaveButton()}
                        />
                    </Grid>
                </Grid>
                <Typography variant={"caption"}
                    sx={{ ml: 4, color: "rgba(0, 0, 0, 0.4)" }}>
                    * Mandatory fields
                </Typography>
            </Grid>

            <DialogComponent 
                isDialogueOpen={postMappingFieldRequested || currentStatusStage !== "Initial"}
                showProgress={true}
                dialogueHeader="Data Ingestion is in Progress"
                dialogueSubject="Please wait for some time as your file is being generated in the back.
                    Kindly do not close this tab"
            />

            <DialogComponent
                showProgress={false}
                isDialogueOpen={resetConfirmPopupOpen}
                dialogueSubjectHeader="Are you sure you want reset"
                dialogueActions={
                    <Grid display="flex" justifyContent="end" alignItems="center" sx={{ pt: 2 }}>
                        <CTA
                            styles={{
                                border: '1px solid #4DBEAC',
                                color: '#4DBEAC', marginRight: '20px'
                            }} 
                            name={"NO"}
                            type={"submit"}
                            onClick={() => setResetConfirmPopupOpen(false)}
                        />
                        <CTA
                            onClick={() => reset()}
                            styles={{ color: '#000', backgroundColor: '#4DBEAC' }}
                            name={"YES"}
                            type={"submit"}
                        />
                    </Grid>
                }
            />
        </Grid>
    )
}

export default GenericListView;
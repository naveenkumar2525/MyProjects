import { Grid } from "@mui/material";

const DataColWrap = ({ children,...props }) => {
    return <Grid item xs={6} {...props}>
        <Grid container xs={12} >
            <Grid item xs={1} />
            <Grid item xs={11} >
                {children}
            </Grid>
            <Grid item xs={12} />
        </Grid>
    </Grid>
}
export default DataColWrap;
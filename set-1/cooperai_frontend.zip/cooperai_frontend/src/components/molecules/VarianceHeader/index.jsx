import { Button, Grid, Link, Typography } from "@mui/material";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import './varianceheader.css';


const VarianceHeader = (props) => {
    const {title, description, to} = props;
    return (
        <Grid 
            container 
            sx={{ minHeight: '20vh', display: 'flex', alignItems: 'center',
            justifyContent: 'space-around', backgroundColor: 'rgba(4, 179, 242, 0.04)'}}
            xs={12}
        >
            <Grid item xs={11}>
                <Grid container justifyContent="space-between" alignItems="center">
                    <Grid item xs={6} alignItems="center">
                        <div className="header-conf"> {title} </div>
                    </Grid>
                    <Grid item xs={6} >
                        <Grid container xs={12} display="flex" justifyContent="flex-end" alignItems="center" spacing={3}>
                            <Link href={to} style={{ textDecoration: "none",marginLeft:"2rem" }}>
                                <Button size="small">
                                    <ArrowBackIcon fontSize="small"/>
                                    <Typography sx={{ ml: 1 }}> Back </Typography>
                                </Button>
                            </Link>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid>
                    <Typography className="description" sx={{ mt: 2}}> {description} </Typography>
                </Grid>
            </Grid>
        </Grid>
    )
}
export default VarianceHeader;
import { Grid } from "@mui/material";
import CTA from "../../atoms/CTA";
import './datarowheader.css';

const DataRowHeader = ({ headerName = '', shouldShowButton = false, buttonName='',onClick = () => { },id }) => {
    return (<Grid id={id} container xs={12} className="rowWraphead ">
        <Grid container xs={6} >
            <Grid item xs={1} />
            <Grid item xs={11} display='flex' justifyContent='space-between'>
                <div className="headertext">{headerName}</div>
            </Grid>
        </Grid>
        {shouldShowButton && <Grid container xs={6} >
            <Grid item xs={1} />
            <Grid item xs={11} display='flex' justifyContent='flex-end'>
                <div className="buttonwrap">
                    <CTA
                        onClick={onClick}
                        styles={{
                            border: '1px solid #4DBEAC',
                            color: '#4DBEAC', marginRight: '20px'
                        }} name={buttonName} type={"submit"} />
                </div>
            </Grid>
        </Grid>}
    </Grid>)
}
export default DataRowHeader;
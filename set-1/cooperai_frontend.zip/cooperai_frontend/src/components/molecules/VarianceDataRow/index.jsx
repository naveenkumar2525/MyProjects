import { Grid } from "@mui/material";
import DropDown from "../../atoms/Dropdown";
import DataColWrap from "../DataColWrap";
import './variancedatarow.css';

const VarianceDataRow = ({ data, plValues, masterData, handleChange}) => {
    
    const getDataType = (type) => {
        let mappedKey = null;
        return mappedKey;
    }

    return (<Grid container className="rowWrap">
        <DataColWrap>
            <Grid container justifyContent={"space-between"} alignItems="center" >
                <Grid item xs={4}>
                    <span className="datasetname">{data.category}</span>
                </Grid>
                <Grid item xs={6}>
                    <Grid container >
                        <Grid item xs={12} className="dropdownrow">
                            <DropDown 
                                values={plValues}
                                emptyText="select From Dropdown"
                                selectedValue={data.plValue}
                                handleChange={(e) => handleChange("plValue", e.target.value)}
                            />
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </DataColWrap>
        <DataColWrap  >
            <Grid container justifyContent={"space-between"} alignItems="center" >
                <Grid item xs={6} className="dropdownrow">
                    <DropDown
                        values={masterData}
                        emptyText="Select From Dropdown"
                        selectedValue={data.masterDataValue}
                        handleChange={(e) => handleChange("masterDataValue", e.target.value)}
                    />
                </Grid>
            </Grid>
        </DataColWrap>
    </Grid>)
}

export default VarianceDataRow;
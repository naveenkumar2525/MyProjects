import React, { useEffect } from 'react';
import { Box } from "@mui/material";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import { makeStyles} from '@mui/styles';
import { setCurrentScreenId } from '../../../redux/DataMappingView/DataMappingViewSlice';
import { useDispatch, useSelector } from 'react-redux';

////////////////////////////////////////////////////////////////////////////

const useStyles = makeStyles({
    tabs: {
      "& .MuiTabs-indicator": {
        backgroundColor: "#000",
        height: 3,
      },
      "& .MuiTab-root.Mui-selected": {
        color: "#000"
      }
    }
})

////////////////////////////////////////////////////////////////////////////

function a11yProps(index) {
    return {
      id: `simple-tab-${index}`,
      'aria-controls': `simple-tabpanel-${index}`,
    };
}

const TabsViewHeader = () => {
    const classes = useStyles();
    const dispatch = useDispatch();
    const { tabValues, currentScreenId } = useSelector((state) => state.dmv);

    const handleChange = (even, newValue) => {
        dispatch({
          type: setCurrentScreenId.type,
          payload: newValue
        })
    };

    const onPress = (e) => {
        e.preventDefault();
        const target = window.document.getElementById(
          e.currentTarget.href.split("#")[1]
        );
        if (target) {
          target.scrollIntoView({ behavior: "smooth" });
        }
      };
    return (
        <Box sx={{ borderBottom: 1, borderColor: 'divider', backgroundColor: "#4DBEAC" }}>
            <Tabs value={currentScreenId} className={classes.tabs} onChange={handleChange}>
                {
                    tabValues?.map((item)=>
                        <Tab label={item.name} {...a11yProps(item.id)} data-to-scrollspy-id={item.id} onClick={(e) => onPress(e)} href={`#${item.id}`}/>
                    )
                }
            </Tabs>
        </Box>    
    )
}

export default TabsViewHeader;
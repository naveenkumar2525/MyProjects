import { Grid } from "@mui/material";
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import DropDown from "../../atoms/Dropdown";
import DataColWrap from "../DataColWrap";
import './datasetrow.css';
import { formatDataInAscendingOrder } from "../../../utilities/helpers";

const fieldTypeOptions = [
    { value: 'STRING', name: 'Text Field' },
    { value: 'NUMBER', name: 'Numeric' },
    { value: 'DATE', name: 'Date' },
]

const DataCol = ({ title = 'Input Column', handleChange = () => { },
    options = [], selectedValue = null, name, disable, className }) => {
    return (<Grid container className={className} >
        <Grid item xs={3} className="fieldtype">
            <span> {title}</span>
        </Grid>
        <Grid item xs={9} className="dropdownrow">
            <DropDown 
                values={options} 
                selectedValue={selectedValue}
                handleChange={handleChange} 
                emptyText='Select an item' 
                disable={disable}
            />
        </Grid>
    </Grid>)
}
const DataSetRow = ({ typeMap, mandate: isMandatory = false, cooperColumn = '', clientDataType = '',
    handleChange = () => { }, clientColumnName = '', clientDatabaseOptions = [], shouldShownJoinRows = false,
    inputColumnOptions = [], mappingColumnOptions = [] ,joinRowParams={left:'',right:''}, uniqueIdRow=true, handleUniqueIdFieldDelete=()=>{}, uniqueIdJoinOptions=[] , handleUniqueIdFieldChange=()=>{} }) => {

    const getDataType = (type) => {
        let mappedKey = null;
        Object.keys(typeMap).map(key => {
            if (typeMap[key] === type) {
                mappedKey = key;
            }
        })
        return mappedKey;
    }

    const filteredClientDatabaseOptions = formatDataInAscendingOrder(clientDatabaseOptions?.filter(v => v.type === clientDataType));

    return (<Grid container className="rowWrap">
        {shouldShownJoinRows ? <>
            <Grid container justifyContent={"space-between"} alignItems="center" minHeight="90px">
                <Grid item xs={5}>
                    <DataCol 
                        title={joinRowParams.left} 
                        options={inputColumnOptions}
                        selectedValue={cooperColumn}
                        handleChange={(e) => handleChange('cooperColumn', e.target.value)}
                        disable={true}
                        className="leftJoinField"
                    />
                </Grid>
                <Grid item xs={2} className="equal">
                    <span >=</span>
                </Grid>
                <Grid item xs={5}>
                    <DataCol 
                        title={joinRowParams.right} 
                        options={mappingColumnOptions}
                        selectedValue={clientColumnName}
                        handleChange={(e) => handleChange('clientColumnName', e.target.value)}
                        disable={true}
                        className="rightJoinField"
                    />
                </Grid>
            </Grid>
        </> : uniqueIdRow ? 
        <Grid container sx={{padding: '0 1rem 0.5rem 4rem'}}>
            { 
            clientColumnName === "" || clientColumnName === null ?
            <Grid item sm={2} xs={10} sx={{display: 'flex', alignItem: 'center', flexDirection: 'row', paddingRight:'2rem'}}>
                <DropDown
                    values={uniqueIdJoinOptions}
                    selectedValue={clientColumnName}
                    handleChange={(e) => handleUniqueIdFieldChange(0, e.target.value)}
                />
            </Grid>
            :
            clientColumnName.split("|").map((v, i) =>
                <Grid key={i} item sm={2} xs={10} sx={{display: 'flex', alignItem: 'center', flexDirection: 'row',paddingRight:'2rem'}}>
                    <DropDown
                        values={uniqueIdJoinOptions}
                        selectedValue={v}
                        handleChange={(e) => handleUniqueIdFieldChange(i, e.target.value)}
                    />
                    {
                        i >=1 &&  <span onClick={() => handleUniqueIdFieldDelete(i)}><DeleteOutlineIcon style={{ marginTop: '40px', marginLeft: '0.5rem' }} /></span>
                    }
                </Grid>
            )}
        </Grid> : 
        <>
            <DataColWrap>
                <Grid container justifyContent={"space-between"} alignItems="center" minHeight="90px">
                    <Grid item xs={4}>
                        <span className="datasetname">{cooperColumn}</span> {isMandatory && <span className="mandate">*</span>}
                    </Grid>
                    <Grid item xs={6}>
                        <Grid container >
                            <Grid item xs={4} className="fieldtype">
                                <span> Field Type:</span>
                            </Grid>
                            <Grid item xs={8} className="dropdownrow">
                                <DropDown 
                                    values={fieldTypeOptions} 
                                    selectedValue={clientDataType ?? "STRING"}
                                    handleChange={(e) => handleChange('clientDataType', getDataType(e.target.value))}
                                />
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </DataColWrap>
            <DataColWrap  >
                <Grid container justifyContent={"space-between"} alignItems="center" minHeight="90px" >
                    <Grid item xs={6} className="dropdownrow">
                        <DropDown
                            emptyText="No mapping"
                            values={filteredClientDatabaseOptions}
                            selectedValue={clientColumnName}
                            handleChange={(e) => handleChange('clientColumnName', e.target.value)}
                        />
                    </Grid>
                </Grid>
            </DataColWrap>
        </>
        }
    </Grid>)
}

export default DataSetRow;
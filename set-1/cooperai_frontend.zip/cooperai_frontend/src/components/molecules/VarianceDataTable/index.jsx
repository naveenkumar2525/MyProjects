import * as React from "react";
import { styled } from "@mui/material/styles";
import {
  Grid,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "rgba(0, 0, 0, 0.1)",
    color: "#000000",
    fontWeight: 700,
    opacity: 0.6,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(even)": {
    backgroundColor: "#F5FCFF",
  },
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const VarianceDataTable = (props) => {
  const { tableHeader, tableData } = props;
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  return (
    <Grid item xs={12}>
      <TableContainer>
        <Table sx={{ minWidth: 700 }}>
          <TableHead>
            <TableRow>
              {tableHeader?.map((header) => (
                <StyledTableCell
                  component="th"
                  align={header.align ? "right" : "left"}
                >
                  {header.label}
                </StyledTableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {tableData?.length > 0 ? (
              tableData
                ?.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row, index) => (
                  <StyledTableRow key={index}>
                    {tableHeader?.map((el, index) => (
                      <StyledTableCell
                        align={el.align ? "right" : "left"}
                        key={index}
                      >
                        {el?.name === "differenceInPercent" ? (
                          <p style={{ color: "red" }}>{row[el.name] == 0 ? '-' : row[el.name]}</p>
                        ) : (['plValue', 'masterDataValue', 'difference'].includes(el.name) &&
                          ![0, '', null, undefined].includes(row[el.name])) ? (
                          new Intl.NumberFormat("en-US", {
                            style: "currency",
                            currency: "USD",
                          }).format(row[el.name])
                        ) : (
                          row[el.name] == 0 ? '0' : row[el.name]
                        )}
                      </StyledTableCell>
                    ))}
                  </StyledTableRow>
                ))
            ) : (
              <StyledTableRow>
                <StyledTableCell align="center" colSpan={tableHeader?.length}>
                  No data Found.
                </StyledTableCell>
              </StyledTableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Grid>
  );
};
export default VarianceDataTable;

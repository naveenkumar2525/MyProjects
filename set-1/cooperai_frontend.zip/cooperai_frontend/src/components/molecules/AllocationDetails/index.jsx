import { Grid } from "@mui/material";
import DropDown from "../../atoms/Dropdown";
import './allocationdetails.css';

const AllocationDetails = ({ dropdownData, handleChange = () => { } }) => {
    return (<Grid container xs={12} className="mainWrap">
        <Grid item xs={12} sx={{ minHeight: "55vh", width: "inherit" }}>
            <span className="header">Allocation Details</span>
            <Grid sx={{ mt: 2}}>
                {dropdownData?.map(({title, options, selectedValue}, index) => {
                    return (
                        <Grid py={1} key={index}>
                            <span className="title">{title}:</span>
                            <Grid className={"dropdown"}>
                                <DropDown 
                                    values={options}
                                    selectedValue={selectedValue}
                                    handleChange={(e) => handleChange(index, title, e.target.value)}
                                />
                            </Grid>
                        </Grid>
                    )
                })}
            </Grid>
        </Grid>
    </Grid>)
}

export default AllocationDetails;
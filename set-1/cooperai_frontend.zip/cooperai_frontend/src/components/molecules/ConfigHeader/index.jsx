import { Grid } from "@mui/material";
import { useDispatch, useSelector } from 'react-redux';
import DropDown from "../../atoms/Dropdown";
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import './configheader.css';
import { setCurrentScreenId, setModule } from "../../../redux/DataMappingView/DataMappingViewSlice";

const Item = styled(Paper)(({ theme }) => ({
    padding: theme.spacing(1),
    textAlign: 'center',

}));

const options=[
    {value: 'Org_module', name: 'Org Module'},
    {value: 'p&l module', name: 'P&L Module'},
    {value: 'Margin_module', name: 'Margin Module'},
    {value: 'Vendor_module', name: 'Vendor Module'}
]

const ConfigHeader = () => {
    const dispatch = useDispatch();
    const { module } = useSelector((state) => state.dmv);

    const handleChange = (e) => {
        dispatch({
            type: setModule.type,
            payload: e.target.value
        });

        dispatch({
            type: setCurrentScreenId.type,
            payload: 0
        })
    }

    return (
        <Grid container sx={{ height: '20vh', display: 'flex', alignItems: 'center', justifyContent: 'space-around', backgroundColor: 'rgba(4, 179, 242, 0.04)'}}
            xs={12} >
            <Grid item xs={11}>
                <Grid container justifyContent="space-between" alignItems="center" spacing={5}>
                    <Grid item xs={6} alignItems="center">
                        <div className="header-conf"> Field Mapping </div>
                    </Grid>
                    <Grid item xs={6} >
                        <Grid container xs={12} display="flex" justifyContent="flex-end" alignItems="center" spacing={3}>
                            <Grid item xs={4} className="modname"> Module Name:</Grid>
                            <Grid item xs={4}><DropDown values={options} selectedValue={module} handleChange={handleChange}/></Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>

        </Grid>
    )
}
export default ConfigHeader;
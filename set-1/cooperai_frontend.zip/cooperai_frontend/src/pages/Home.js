import React from 'react';
import { Grid, Typography } from '@mui/material';
import { makeStyles } from '@mui/styles';
import Header from './../sections/Header';
import SunImage from './../assets/sunrise.png';

///////////////////////////////////////////////////////////////////////

const useStyles = makeStyles((theme) => ({
    mainWrapper: {
        minHeight: '100vh',
        justifyContent:'center',
        backgroundColor: '#071E3A'
    }
}))

///////////////////////////////////////////////////////////////////////

export default function Home() {
    const classes = useStyles();

    return(
        <Grid className={classes.mainWrapper}>
            <Grid sx={{ height: '10vh'}}>
                <Header />
            </Grid>
            <Grid sx={{ height: '90vh'}} display="flex" alignItems="center" justifyContent="center">
                <SplashScreen />
            </Grid>
        </Grid>
    )
};

const SplashScreen = () => {
    return (
        <Grid sx={{ height: '300px'}}>
            <Grid display="flex" justifyContent={"center"}>
                <img src={SunImage} alt="sun_rise" loading="lazy" height="60" width="110"/>
            </Grid>
            <Typography variant='h2' color="#fff" sx={{ mt: 1 }}>Good Morning!</Typography>
            <Typography variant='h6' color="#fff" sx={{ mt: 2 }}>Just a sec while we gather today's decisions...</Typography>
        </Grid>
    )
}
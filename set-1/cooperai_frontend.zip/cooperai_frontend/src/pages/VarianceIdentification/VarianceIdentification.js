import React from 'react';
import { Grid } from '@mui/material';
import { makeStyles } from '@mui/styles';
import { useParams } from 'react-router-dom';
import Header from './../../sections/Header';
import VarianceHeader from '../../components/molecules/VarianceHeader';
import VarianceDataList from '../../components/organisms/VarianceDataList';

///////////////////////////////////////////////////////////////////////

const useStyles = makeStyles((theme) => ({
    mainWrapper: {
        minHeight: '100vh',
        justifyContent: 'center',
        backgroundColor: '#FFFFFF'
    }
}))

///////////////////////////////////////////////////////////////////////

export default function VarianceIdentification() {
    const classes = useStyles();
    const { clientName } = useParams();

    return (
        <Grid className={classes.mainWrapper}>
            <Grid sx={{ height: '10vh' }}>
                <Header />
            </Grid>
            <Grid container xs={12}>
                <Grid item xs={12}>
                    <VarianceHeader 
                        title="Variance Identification"
                        description="Based on the previous inputs, we found below mismatch. Please review and re-allocate."
                        to={`/client/${clientName}`} 
                    />
                </Grid>
                <Grid item xs={12}>
                    <VarianceDataList />
                </Grid>
            </Grid>
        </Grid>
    )
};


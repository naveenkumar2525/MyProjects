import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { makeStyles } from '@mui/styles';
import { useDispatch, useSelector } from 'react-redux';
import FormInput from './../../components/atoms/FormInput';
import CLink from './../../components/atoms/CLink';
import CTA from './../../components/atoms/CTA';
import useForm from './../../hooks/useForm';
import { Checkbox, Grid, Typography } from '@mui/material';
import Logo from './../../assets/logo_cooper.png';
import FooterLogo from './../../assets/footer_logo_cooper.png';
import Header from './../../sections/Header';
import { setSignedInState } from './../../redux/AuthManagement/AuthManagementSlice';

//////////////////////////////////////////////////////////////////////////////

const useStyles = makeStyles((theme) => ({
    mainWrapper: {
        minHeight: '100vh',
        justifyContent:'center',
        backgroundColor: '#071E3A'
    }
}))

//////////////////////////////////////////////////////////////////////////////

export default function Login() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { values, handleChange } = useForm({
        initialValues: {
            email: '',
            password: ''
        }
    });
    const [ showPassword, setShowPassword ] = useState(false);
    const { keepMeSignedIn } = useSelector((state) => state.auth);

    const handleLogin = async (e) => {
        e.preventDefault();
        dispatch({
            type: "LOGIN_REQUEST_ACTION",
            payload: { values, navigate, keepMeSignedIn}
        });
    }

    const handleClickShowPassword = () => {
        setShowPassword(!showPassword);
    };
    
    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

    const validateSignInForm = () => {
        if (values.email?.trim()?.length && values.password?.trim()?.length) {
            return false;
        }
        return true;
    }

    const handleKeepSignInChange = () => {
        dispatch({
            type: setSignedInState.type,
            payload: !keepMeSignedIn
        });
    }

    const accessToken = localStorage.getItem("accessToken");
    const sessionToken = sessionStorage.getItem("accessToken");

    useEffect(()=> {
        if(accessToken || sessionToken) {
            navigate('/home');
        }
    }, []);

    return(

        <Grid className={classes.mainWrapper}>
            <Grid sx={{ height: '10vh'}}>
                <Header />
            </Grid>
            <Grid display="flex" alignItems="center" sx={{ height: '80vh'}}>
                <Grid container>
                    <Grid sm="2" xs="none"></Grid>
                    <Grid container sm="8" xs="12">
                        <Grid sm="6" xs="12" display="flex" justifyContent="center">
                            <img
                                src={Logo}
                                alt="logo"
                                loading="lazy"
                            />
                        </Grid>
                        <Grid sm="6" xs="12" sx={{ borderLeft: '0.5px solid rgba(255, 255, 255, 0.5)'}}>
                            <Grid sx={{ width: '70%', marginLeft: '15%'}}>
                                <form onSubmit={handleLogin}>
                                    <FormInput type={"text"} 
                                                placeholder={"Email"} 
                                                name={"email"}
                                                value={values.email}
                                                label={"Email"}
                                                handleChange={handleChange} />
                                    <FormInput type={showPassword? "text": "password"}
                                                placeholder={"Password"} 
                                                name={"password"}
                                                label={"Password"}
                                                value={values.password} 
                                                showPassword={showPassword}
                                                handleChange={handleChange}
                                                endAdornment={true}
                                                handleClickShowPassword={handleClickShowPassword}
                                                handleMouseDownPassword={handleMouseDownPassword}
                                                />
                                    <Grid display="flex" alignItems="center" sx={{ mt: 2 }}> 
                                        <Checkbox
                                            sx={{
                                                color: '#4DBEAC',
                                                '&.Mui-checked': {
                                                color: '#4DBEAC',
                                                },
                                            }}
                                            checked={keepMeSignedIn}
                                            onChange={handleKeepSignInChange}
                                        />
                                        <Typography variant="subtitle2" sx={{ color: '#fff'}}>Keep Me Signed In</Typography>
                                    </Grid>
                                    <Grid display="flex" justifyContent="space-between" alignItems="end" sx={{ mt: 2 }}> 
                                        <CTA isDisabled={validateSignInForm()} styles={{color: '#000', backgroundColor: '#4DBEAC'}} name={"SIGN IN"} type={"submit"} />
                                        <CLink label="Forgot Your Password"/>
                                    </Grid>
                                </form>
                            </Grid>
                        </Grid>
                    </Grid>
                    <Grid sm="2"></Grid>
                </Grid>
            </Grid>
            <Grid sx={{ height: '10vh'}}>
                <Grid display="flex" justifyContent="center" alignItems="center">
                    <CLink label="Privacy Policy "/>
                    <Typography variant="subtitle1" sx={{ color: 'rgba(255, 255, 255, 0.5)', ml:1}}>
                        | @2022 Cooper, Inc. All Rights Reserved.</Typography>
                </Grid>
                <Grid sx={{ ml: 2}}>
                    <img
                        src={FooterLogo}
                        alt="foooter_logo"
                        loading="lazy"
                    />
                </Grid>
            </Grid>
        </Grid>
    )
}
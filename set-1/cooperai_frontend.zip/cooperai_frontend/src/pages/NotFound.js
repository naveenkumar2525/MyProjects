import React from 'react';

export default function NotFound() {
    return(
        <div>
            You seem lost. 
        </div>
    )
}
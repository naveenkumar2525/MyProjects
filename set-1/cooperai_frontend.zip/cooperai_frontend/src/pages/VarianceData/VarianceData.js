import React, { useEffect } from 'react';
import { Grid } from '@mui/material';
import { makeStyles } from '@mui/styles';
import Header from './../../sections/Header';
import VarianceHeader from '../../components/molecules/VarianceHeader';
import VarianceDataTable from '../../components/molecules/VarianceDataTable';
import { useNavigate, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { setModule } from '../../redux/DataMappingView/DataMappingViewSlice';
import CTA from '../../components/atoms/CTA';

///////////////////////////////////////////////////////////////////////

const useStyles = makeStyles((theme) => ({
  mainWrapper: {
    minHeight: '100vh',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF'
  }
}))

///////////////////////////////////////////////////////////////////////

const tableHeader = [
  { name: "plMapping", align: false, label: "Category" },
  { name: "plValue", align: true, label: "P&L Value" },
  { name: "masterDataValue", align: true, label: "Master Data Value" },
  { name: "difference", align: true, label: "Difference" },
  { name: "differenceInPercent", align: true, label: "Differences (%)" },
];

export default function VarianceData() {
  const classes = useStyles();
  const navigate = useNavigate();
  const { clientName } = useParams();

  const dispatch = useDispatch();
  const { varianceAllocationData } = useSelector((state) => state.vdm);

  useEffect(() => {
    dispatch({
      type: "GET_VARIENCE_ALLOCATION_DATA_ACTION",
      payload: clientName
    });
  }, [])

  const handleProceed = () => {
    navigate(`/client/${clientName}/performance_allocation`);
  }

  const handleRestart = () => {
    dispatch({
      type: setModule.type,
      payload: "Margin_module"
    });
    navigate(`/client/${clientName}`);
  }

  return (
      <Grid className={classes.mainWrapper}>
          <Grid sx={{ height: '10vh' }}>
              <Header />
          </Grid>
          <Grid container xs={12}>
              <Grid item xs={12}>
                  <VarianceHeader title="Variance Data"
                      description="Based on the previous inputs, we found below mismatch. Please review and re-allocate."
                      to={`/client/${clientName}/variance_identification`} />
              </Grid>
              <Grid item xs={12} sx={{ height: '60vh'}}>
                  <VarianceDataTable tableHeader={tableHeader} tableData={varianceAllocationData} />
              </Grid>
              <Grid container justifyContent="flex-end">
                  <Grid item xs={2} display="flex" alignItems={"center"} sx={{ pt: 2 }}>
                      <CTA
                          styles={{border: '1px solid #4DBEAC',color: '#4DBEAC', marginRight: '20px'}} 
                          name={"RESTART"} 
                          type={"reset"} 
                          onClick={handleRestart}
                      />
                      <CTA
                          styles={{ color: '#000', backgroundColor: '#4DBEAC' }}
                          name={"PROCEED"}
                          type={"submit"}
                          onClick={handleProceed}
                      />
                  </Grid>
              </Grid>
          </Grid>
      </Grid>
  )
};
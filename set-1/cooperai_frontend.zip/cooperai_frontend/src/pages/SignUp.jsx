import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { makeStyles } from '@mui/styles';
import FormInput from '../components/atoms/FormInput';
import CTA from '../components/atoms/CTA';
import useForm from './../hooks/useForm';
import { Grid } from '@mui/material';
import Logo from './../assets/logo_cooper.png'
import Header from '../sections/Header';
import { useDispatch } from 'react-redux';

//////////////////////////////////////////////////////////////////////////////

const useStyles = makeStyles((theme) => ({
    mainWrapper: {
        height: '100vh',
        justifyContent: 'center',
        backgroundColor: '#071E3A'
    }
}))

//////////////////////////////////////////////////////////////////////////////
const formElements = [{ type: "text", placeholder: "First Name", name: "firstname", label: "First Name" },
{ type: "text", placeholder: "Last Name", name: "lastname", label: "Last Name" },
{ type: "text", placeholder: "Email", name: "email", label: "Email" }]
export default function SignUp() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { values, handleChange } = useForm({
        initialValues: {
            firstname: '',
            lastname: '',
            email: '',
            password: ''
        }
    });
    const [showPassword, setShowPassword] = useState(false);

    const handleLogin = async (e) => {
        e.preventDefault();
        dispatch({
            type: "SIGNUP_REQUEST_ACTION",
            payload: { values, navigate}
        });
    }

    const handleClickShowPassword = () => {
        setShowPassword(!showPassword);
    };

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };

    const validateSignUpForm = () => {
        if (values.firstname?.trim()?.length && values.lastname?.trim()?.length 
        && values.email?.trim()?.length && values.password?.trim()?.length ) {
            return false;
        }
        return true;
    }

    const accessToken = localStorage.getItem("accessToken");
    const sessionToken = sessionStorage.getItem("accessToken");

    useEffect(()=> {
        if(accessToken || sessionToken) {
            navigate('/home');
        }
    }, []);

    return (

        <Grid className={classes.mainWrapper}>
            <Header isLogin={false} />
            <Grid container sx={{ marginTop: '120px' }}>
                <Grid sm="2" xs="none"></Grid>
                <Grid container sm="8" xs="12">
                    <Grid sm="6" xs="12" display="flex" justifyContent="center">
                        <img
                            src={Logo}
                            alt="logo"
                            loading="lazy"
                        />
                    </Grid>
                    <Grid sm="6" xs="12" sx={{ borderLeft: '0.5px solid rgba(255, 255, 255, 0.5)' }}>
                        <Grid sx={{ width: '70%', marginLeft: '15%' }}>
                            <form onSubmit={handleLogin}>
                                {formElements?.map(props => <FormInput {...props} value={values[props.name]}
                                    key={props.name} handleChange={handleChange} />)}

                                <FormInput type={!showPassword ? "password" : "text"}
                                    placeholder={"Password"}
                                    name={"password"}
                                    label={"Password"}
                                    value={values.password}
                                    showPassword={showPassword}
                                    handleChange={handleChange}
                                    endAdornment={true}
                                    handleClickShowPassword={handleClickShowPassword}
                                    handleMouseDownPassword={handleMouseDownPassword}
                                />

                                <Grid display="flex" justifyContent="space-between" alignItems="end" sx={{ mt: 2 }}>
                                    <CTA isDisabled={validateSignUpForm()} styles={{ color: '#000', backgroundColor: '#4DBEAC' }} name={"SIGN UP"} type={"submit"} />
                                </Grid>
                            </form>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid sm="2"></Grid>
            </Grid>
        </Grid>
    )
}
import React, { useEffect, useState } from 'react';
import { Grid } from '@mui/material';
import { makeStyles } from '@mui/styles';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import Header from '../../sections/Header';
import VarianceHeader from '../../components/molecules/VarianceHeader';
import VarienceDataTable from '../../components/molecules/VarianceDataTable';
import CTA from '../../components/atoms/CTA';
import AllocationDetails from '../../components/molecules/AllocationDetails';
import { 
    setAllocationStatus,
    setVarianceAllocationData
} from '../../redux/VarianceDataManagement/VarianceDataManagementSlice';
import DialogComponent from '../../components/atoms/Dialogue';
import { setCurrentStatusStage } from '../../redux/DataMappingView/DataMappingViewSlice';

///////////////////////////////////////////////////////////////////////

const useStyles = makeStyles((theme) => ({
    mainWrapper: {
        minHeight: '100vh',
        justifyContent: 'center',
        backgroundColor: '#FFFFFF'
    }
}))

///////////////////////////////////////////////////////////////////////

const tableHeader = [
    { name: "plMapping", align: false, label: "Category" },
    { name: "plValue", align: true, label: "P&L Value" },
    { name: "masterDataValue", align: true, label: "Master Data Value" },
    { name: "difference", align: true, label: "Difference" },
    { name: "differenceInPercent", align: true, label: "Differences (%)" },
];

const tableData = [
    {
        category: "Total Revenue",
        plValue: 200000,
        masterDataValue: 160000,
        difference: 20000,
        differences: 10,
    },
    {
        category: "Raw Material Cost",
        plValue: 80000,
        masterDataValue: 80000,
    },
    {
        category: "Lorem Cost",
        plValue: 320000,
        masterDataValue: 400000,
        difference: 40000,
        differences: 20,
    },
    {
        category: "Dummy Cost 1",
        plValue: 1150000,
        masterDataValue: 1000000,
        difference: 150000,
        differences: 15,
    }
];
const options= [
    { value: "% of gross revenue", name: "% of gross revenue" },
    { value: "% of net revenue", name: "% of net revenue" },
    { value: "% of total quantity", name: "% of total quantity" },
    { value: "% of number of rows", name: "% of Number of rows" }
]
const data = [
    {
        title: "Net Revenue Variance Allocation Method",
        options,
        selectedValue: ""
    },
    {
        title: "Cost Bucket 1 Variance allocation Method",
        options,
        selectedValue: ""
    },
    {
        title: "Cost Bucket 2 Variance allocation Method",
        options,
        selectedValue: ""
    },
    {
        title: "SG&A Variance Allocation Method",
        options,
        selectedValue: ""
    },
]

export default function PerformAllocation() {
    const classes = useStyles();
    const { clientName } = useParams();
    const dispatch = useDispatch();
    const { varianceAllocationData, dataAllocationStatus } = useSelector((state) => state.vdm);
    const { module, currentStatusStage } = useSelector((state) => state.dmv);

    const [dropdownData, setDropdownData] = useState([]);

    useEffect(() => {
        if (varianceAllocationData?.length && !dropdownData?.length) {
            let _dropdownData = data?.map(({ title, selectedValue, ...rest }, index) => (
                { 
                    title: `${varianceAllocationData[index]?.plMapping} Variance Allocation Method`,
                    selectedValue: varianceAllocationData[index]?.allocationMethod, ...rest
                }));
            setDropdownData(_dropdownData);
        }
    }, [varianceAllocationData])

    const handleChange = (index, key, value) => {
        let data = JSON.parse(JSON.stringify(dropdownData));
        data[index]["selectedValue"] = value;
        setDropdownData(data);

        let newData = JSON.parse(JSON.stringify(varianceAllocationData));
        newData[index].allocationMethod = value;
        dispatch({
            type: setVarianceAllocationData.type,
            payload: newData
        });
    }

    useEffect(() => {
        dispatch({
            type: "GET_VARIENCE_ALLOCATION_DATA_ACTION",
            payload: clientName
        });
    }, [])

    const handleReset = () => {
        dispatch({
            type: "GET_VARIENCE_ALLOCATION_DATA_ACTION",
            payload: clientName
        });
    }

    const handleSubmit = () => {
        dispatch({
            type: setCurrentStatusStage.type,
            payload: "Calculations" 
        });
        dispatch({
            type: "SAVE_VARIENCE_ALLOCATION_DATA_ACTION",
            payload: { clientName, body: varianceAllocationData, module: "Margin_module", currentStatusStage: "Calculations" }
        });
    }

    const validateSubmitButton = () => {
        return dropdownData.some(v=>(v.selectedValue === "" || v.selectedValue === null));
    }

    useEffect(() => {
        const interval = setInterval( async() => {
            if (dataAllocationStatus === "INPROGRESS") {
                dispatch({
                    type: "GET_ALLOCATION_STATUS_ACTION",
                    payload: { 
                        module: "Margin_module",
                        clientName,
                        currentStatusStage
                    }
                });
            } else {
                clearInterval(interval)
            }
        }, 15000);
        return () => clearInterval(interval);
    }, [dataAllocationStatus]);

    const handleProceed = (status) => {
        //Changing the status to Sanity for Proceed funtionality
        dispatch({
            type: setCurrentStatusStage.type,
            payload: "Sanity" 
        });
        //Proceed for Allocation API Service call
        dispatch({
            type: "PROCEED_FOR_ALLOCATION_ACTION",
            payload: { clientName, module: "Margin_module", status, currentStatusStage: "Sanity" }
        });
        if (status === "N") {
            //For user's No action stopping the progress popup
            dispatch({
                type: setAllocationStatus.type,
                payload: ""
            });
        }
    }

    useEffect(()=> {
        if(dataAllocationStatus === "SUCCESS" && currentStatusStage === "Analytics") {
            dispatch({
                type: "PROCEED_FOR_ANALYTICS_ACTION",
                payload: { clientName, module: "Margin_module", currentStatusStage }
            });
        }
    }, [currentStatusStage, dataAllocationStatus])

    return (
        <Grid className={classes.mainWrapper}>
            <Grid sx={{ height: '10vh' }}>
                <Header />
            </Grid>
            <Grid container xs={12}>
                <Grid item xs={12}>
                    <VarianceHeader title="Perform Allocation"
                        description="Perform Allocation across all Variances to come up with final “Row-level EBITDA” "
                        to={`/client/${clientName}/variance_data`} />
                </Grid>
            </Grid>
            <Grid container xs={12} sx={{ backgroundColor: "#F8F8F8" }}>
                <Grid item xs={8} pt={1} pr={1}>
                    <VarienceDataTable tableHeader={tableHeader} tableData={varianceAllocationData} />
                </Grid>
                <Grid item xs={4} px={3} pt={1} borderLeft="2px solid #0000003D">
                    <AllocationDetails
                        dropdownData={dropdownData}
                        handleChange={(index, key, value) => handleChange(index, key, value)}
                    />
                </Grid>
            </Grid>
            <Grid item xs={12}>
                <Grid container justifyContent="flex-end">
                    <Grid item xs={2} display="flex" alignItems={"center"} sx={{ py: 2 }}>
                        <CTA
                            styles={{ border: '1px solid #4DBEAC', color: '#4DBEAC', marginRight: '20px' }}
                            name={"RESET"}
                            type={"reset"}
                            onClick={handleReset}
                        />
                        <CTA
                            styles={{ color: '#000', backgroundColor: '#4DBEAC' }}
                            name={"SUBMIT"}
                            type={"submit"}
                            isDisabled={validateSubmitButton()}
                            onClick={handleSubmit}
                        />
                    </Grid>
                </Grid>
            </Grid>

            <DialogComponent 
                isDialogueOpen={currentStatusStage === "Calculations" && dataAllocationStatus === "INPROGRESS"}
                showProgress={true}
                dialogueHeader="Data Submission is in Progress"
                dialogueSubject="Please wait for some time as your file is being generated in the back.
                Kindly do not close this tab"
            />

            <DialogComponent 
                isDialogueOpen={["ERROR", "HOLD"].includes(dataAllocationStatus)}
                showProgress={false}
                dialogueSubject="Exception report is generated. Please validate and Confirm"
                dialogueActions={
                        <Grid 
                            item 
                            xs={2}
                            display="flex"
                            justifyContent={"end"}
                            alignItems={"center"}
                            sx={{ py: 2, mt: 2 }}
                        >
                            <CTA
                                styles={{ border: '1px solid #4DBEAC', color: '#4DBEAC', marginRight: '20px' }}
                                name={"CANCEL"}
                                type={"reset"}
                                onClick={()=>handleProceed("N")}
                            />
                            <CTA
                                styles={{ color: '#000', backgroundColor: '#4DBEAC' }}
                                name={"PROCEED"}
                                type={"submit"}
                                onClick={()=>handleProceed("Y")}
                            />
                        </Grid>
            }/>
               
            <DialogComponent
                isDialogueOpen={currentStatusStage === "Sanity" || currentStatusStage === "Analytics"}
                showProgress={true}
                dialogueHeader="Analytics Generation is in progress"
                dialogueSubject="Please wait for some time as your file is being generated in the back.
                Kindly do not close this tab"
            />
        </Grid>
    )
};


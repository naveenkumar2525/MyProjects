import React, { useEffect, useState } from 'react';
import { Grid } from '@mui/material';
import { makeStyles } from '@mui/styles';
import { useNavigate, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Header from './../../sections/Header';
import SplashScreen from '../../components/organisms/SplashScreen';
import ConfigHeader from '../../components/molecules/ConfigHeader';
import DataList from '../../components/organisms/DataList';

///////////////////////////////////////////////////////////////////////

const useStyles = makeStyles((theme) => ({
    mainWrapper: {
        minHeight: '100vh',
        justifyContent: 'center',
        backgroundColor: '#FFFFFF'
    }
}))

///////////////////////////////////////////////////////////////////////

export default function DataMappingView() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { clientName } = useParams();
    const { module, postMappingFieldSuccess, currentStatusStage} = useSelector((state) => state.dmv);
    const [ showSplash, setShowSplash ] = useState(true);

    useEffect(() => {
        setTimeout(() => {
            setShowSplash(false)
        }, 1000)

        dispatch({
            type: "GET_MODULE_FIELDS_MAPPING_ACTION",
            payload: { 
                module,
                clientName
            }
        });
    }, [module])

    useEffect(() => {
        const interval = setInterval( async() => {
            if (postMappingFieldSuccess === "INPROGRESS") {
                dispatch({
                    type: "GET_MAPPING_STATUS",
                    payload: { 
                        module,
                        clientName,
                        currentStatusStage
                    },
                });
            } else {
                clearInterval(interval)
            }
        }, 10000);
        return () => clearInterval(interval);
    }, [postMappingFieldSuccess]);

    useEffect(() => {
        if (postMappingFieldSuccess === "SUCCESS" && currentStatusStage === "Analytics" && module === "Vendor_module") {
            dispatch({
                type: "GET_AP_ANALYTICS_STATUS",
                payload: { 
                    module,
                    clientName,
                    currentStatusStage
                },
            });
        }
    }, [currentStatusStage, postMappingFieldSuccess]);


    useEffect(() => {
        if (module === "Margin_module" && postMappingFieldSuccess === "SUCCESS") {
            navigate(`/client/${clientName}/variance_identification`);
        }
    }, [postMappingFieldSuccess])

    return (
        <Grid className={classes.mainWrapper}>
            <Grid sx={{ height: '10vh' }}>
                <Header />
            </Grid>
            {showSplash && <Grid sx={{ height: '90vh' }} display="flex" alignItems="center" justifyContent="center">
                <SplashScreen />
            </Grid>}
            {showSplash || <Grid container sx={{ height: '90vh' }} display="flex" alignItems="flexstart" justifyContent="flex-start" direction={"column"}>
                <Grid item>
                    <ConfigHeader />
                </Grid>
                <Grid item>
                    <DataList clientName={clientName}/>
                </Grid>
            </Grid>}
        </Grid>
    )
};


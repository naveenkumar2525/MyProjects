import { Navigate, Outlet } from 'react-router-dom';

export const ProtectedRoute = ({
  redirectPath = '/login',
  children,
}) => {
  const accessToken = localStorage.getItem("accessToken");
  const sessionToken = sessionStorage.getItem("accessToken");

  if(accessToken || sessionToken){
    return children ? children : <Outlet />;
  }
  return <Navigate to={redirectPath} />;
};
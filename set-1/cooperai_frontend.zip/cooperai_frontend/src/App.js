import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; 
import { Provider } from 'react-redux'
import { Box } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { SnackbarProvider } from 'notistack';
import './App.css';
import { SuccessSnackbar } from './components/atoms/Snackbar';
import { ErrorSnackbar } from './components/atoms/Snackbar';
import { UserContext } from './hooks/UserContext';
import { ProtectedRoute } from './pages/PrivateRoute';
import SignUp from './pages/SignUp';
import Login from './pages/Login/Login';
import DataMappingView from './pages/DataMappingView/DataMappingView';
import NotFound from './pages/NotFound';
import useFindUser from './hooks/useFindUser';
import { Store } from './redux/store';
import VarianceIdentification from './pages/VarianceIdentification/VarianceIdentification';
import VarianceData from './pages/VarianceData/VarianceData';
import PerformAllocation from './pages/PerformanceAllocation';

const theme = createTheme({
  palette: {
    primary: {
      main: '#4DBEAC',
    },
    disabled: {
      main: '#cccccc'
    }
  },
});

function App() {
  
  const { 
    user, 
    setUser, 
    isLoading } = useFindUser();

  return (
   <Router>
      
       <Box>
          <Provider store={Store}>
            <ThemeProvider theme={theme}>
                <UserContext.Provider value={{ user, setUser, isLoading }}>
                  <SuccessSnackbar />
                  <ErrorSnackbar />
                  <SnackbarProvider>
                    <Routes>
                        <Route exact path="/" element={<Login/>}/>  
                        <Route path="/register" element={<SignUp/>}/>
                        <Route path="/login" element={<Login/>}/>
                        <Route path="client/:clientName" element={<DataMappingView />} />
                        <Route path="client/:clientName/variance_identification" element={<VarianceIdentification />} />
                        <Route path="client/:clientName/variance_data" element={<VarianceData />} />
                        <Route path="client/:clientName/performance_allocation" element={<PerformAllocation />} />
                        <Route element={<ProtectedRoute />}>
                          <Route path="/" element={<DataMappingView />} />
                          <Route path="home" element={<DataMappingView />} />
                        </Route>
                        <Route element={<NotFound/>}/>
                    </Routes>
                    </SnackbarProvider>
                  </UserContext.Provider>
            </ThemeProvider>
          </Provider>
       </Box>
   </Router>
  );
}

export default App;

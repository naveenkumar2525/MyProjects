<p>React starter kit is a full-featured React Material UI Admin Dashboard template</p>

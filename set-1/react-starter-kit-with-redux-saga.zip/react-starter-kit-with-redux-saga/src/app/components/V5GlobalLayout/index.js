import React from 'react'

export const V5GlobalLayouts = {
    layout1: React.lazy(() => import('./Layout1/Layout1')),
}

import * as widgets from './widgets.mjs';

export * from './Widget.mjs';
export { widgets }

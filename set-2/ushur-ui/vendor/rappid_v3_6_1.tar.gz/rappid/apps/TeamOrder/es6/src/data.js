
export const members = [
    {
        "name": "Steven Stamkos",
        "color": "#FFAB40"
    },
    {
        "name": "Andrei Vasilevskiy",
        "color": "#FF9E80"
    },
    {
        "name": "Nikita Kucherov",
        "color": "#FF8A80"
    },
    {
        "name": "Brayden Point",
        "color": "#FF80AB"
    },
    {
        "name": "Nick Paul",
        "color": "#EA80FC"
    },
    {
        "name": "Brandon Hagel",
        "color": "#B388FF"
    },
    {
        "name": "Corey Perry",
        "color": "#8C9EFF"
    },
    {
        "name": "Callan Foote",
        "color": "#82B1FF"
    },
    {
        "name": "Victor Hedman",
        "color": "#80D8FF"
    },
    {
        "name": "Patrick Maroon",
        "color": "#18FFFF"
    },
    {
        "name": "Ross Colton",
        "color": "#69F0AE"
    },
    {
        "name": "Zach Bogosian",
        "color": "#1DE9B6"
    }
];

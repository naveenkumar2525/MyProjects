import 'core-js/stable';
import 'regenerator-runtime/runtime';
import '@clientio/rappid/rappid.css';
import './styles.scss';
import { init } from './src/app';

init();

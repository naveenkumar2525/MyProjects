import * as React from 'react';
import Rappid from './rappid';

class App extends React.Component {
    public render() {
        return (
            <Rappid/>
        );
    }
}

export default App;

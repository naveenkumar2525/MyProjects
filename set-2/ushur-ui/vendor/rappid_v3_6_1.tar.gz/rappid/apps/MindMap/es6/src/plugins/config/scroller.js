
export default {
    cursor: 'grab',
    padding: 100,
    autoResizePaper: false
};

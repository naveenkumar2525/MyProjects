import { Collection } from 'backbone';

export default class IdeaCollection extends Collection {
}

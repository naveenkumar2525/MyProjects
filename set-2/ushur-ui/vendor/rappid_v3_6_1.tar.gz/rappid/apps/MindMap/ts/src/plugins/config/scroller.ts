import { ui } from '@clientio/rappid';

export default {
    cursor: 'grab',
    padding: 100,
    autoResizePaper: false
} as Partial<ui.PaperScroller.Options>;
